<?php

class GroupController extends BaseController {
    public function __construct(){
        $this->group_model = new Group();
    }

    public function getAll(){
        $groups = $this->group_model->getGroups();
        $data['groups'] = $groups;
        return View::make('grouplist', $data);
    }
    
    public function getUpdate($id){
        $group = $this->group_model->getGroup($id);
        

        $data = array(
            'post' => (array)$group,
            'error_messages' => array(),
        );
        
        return View::make('groupedit', $data);
        
    }
    public function update($id){
        $group['id'] = $id;
        $group['name'] = Input::get('name');
        $group['created'] = date('Y-m-d H:i:s');
        
        $rules = array(
            'name' => 'required|unique:usersgroups,id,'.$id
        );
        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails())
        {
            $messages = $validator->messages();

            $data = array(
                'post' => $group,
                'error_messages' => $messages->all(),
            );
            
            return View::make('groupedit', $data);
        }
        $group_id = $this->group_model->updateGroup($id, $group);


        if($group_id){
            return Redirect::to('group/'.$id)->with('success_message', "Successfully updated");
        }

    }

    public function getAdd(){
        $group = array(
            'name' => '',
        );
        $data = array(
            'post' => $group,
            'error_messages' => array(),
        );
        
        return View::make('groupadd', $data);
    }
    
    public function add(){
        $group = array(
            'name' => Input::get('name'),
            'created' => date('Y-m-d H:i:s')
        );
        $rules = array(
            'name' => 'required|unique:usersgroups'
        );
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails())
        {
            $messages = $validator->messages();
            $data = array(
                'post' => $group,
                'error_messages' => $messages->all(),
            );
            return View::make('groupadd', $data);
        }
        $group_id = $this->group_model->addGroup($group);
        
        if($group_id){
            return Redirect::to('groups');
        }
    }
    
    public function getDelete($id){
        $this->group_model->deleteGroup($id);
        return Redirect::to('groups');
    }
    

}