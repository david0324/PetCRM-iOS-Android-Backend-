<?php

class HomeController extends BaseController {

    public function index(){
        return View::make('dashboard');
    }
    
	public function showWelcome()
	{
		return View::make('hello');
	}

}