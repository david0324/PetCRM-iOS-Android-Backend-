<?php

class APIController extends BaseController {
    public function __construct(){
//        $fp = fopen('upload/data.txt', 'w');
//        fwrite($fp, json_encode($_SERVER));
//        fwrite($fp, json_encode($_FILES));
//        fwrite($fp, json_encode($_REQUEST));
//        fclose($fp);

        $this->token = Input::get('token', '');
        $this->user_model = new User();
        $this->security_model = new Security();
        $this->group_model = new UserGroup();
        $this->user_id = '';
        $this->data = array(
            'error' => false
        );
    }
    
    
    private function _JsonOutput(){
        header("access-control-allow-origin: *");
        header('Content-Type: application/json');
        echo json_encode($this->data);
        exit;
    }
    
    private function _createToken(){
        $len = rand(1,1000);
        $token = md5(time().$len);
        $row = Token::where('token', $token)->first();
        if($row){
            $token = $this->_createToken();
        }
        return $token;
    }
    
    private function _insertToken($user_id, $token){
        $this->token_model->updateToken($user_id, $token);
    }
    
    public function getIndex(){
    }
    
    private function generateApiKey() {
        return md5(uniqid(rand(), true));
    }   

    public function updateDeviceToken($user_id){
        if(Input::get('io_token', false)){
            IoToken::updateToken($user_id, Input::get('io_token'));
        }
        if(Input::get('android_token', false)){
            AndroidToken::updateToken($user_id, Input::get('android_token'));
        }
    }
    
    public function postGetSecuritiesGroups(){
        $all_groups = $this->group_model->getGroups();
        $groups = array();
        foreach($all_groups as $group){
            if($group->id==2 || $group->id==3){
                $groups[] = $group;
            }
        }
        
        $securities = $this->security_model->getSecurities();
        $this->data = array(
            'error' => false,
            'groups' => $groups,
            'securities' => $securities,
        );
        $this->_JsonOutput();
    }
    
    public function postRegister(){
        $user = array(
            'email' => Input::get('email', ''),
            'username' => Input::get('username', ''),
            'group_id' => Input::get('group_id', ''),
            'security_question' => Input::get('security_question', ''),
            'security_answer' => Input::get('security_answer', ''),
            'fb_token' => Input::get('fb_token', ''),
            'social_type' => Input::get('social_type', ''),
            'password' => Input::get('password', ''),
            'created_at' => date('Y-m-d H:i:s'),
        );
            
        $rules = array(
            'email' => 'required|email',
            'username' => 'required',
            'group_id' => 'required',
            'security_question' => 'required',
            'security_answer' => 'required',
//            'password' => 'required',
        );

        if(!Input::get('fb_token')){
            $rules['password'] = "required";
        }else{
            $rules['social_type'] = "required";
        }
        
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $this->data = array(
                'error' => true,
                'error_code' => 1,
                'message' => implode("\n", $messages->all()),
            );
        }else{
            $db_user = User::where('email', Input::get('email'))
                    ->first();
            if(!Input::get('fb_token')){
                /**
                * normal register
                */
                if($db_user){
                    $res = USER_ALREADY_EXISTED;
                }else{
                    $user['password'] = Hash::make($user['password']);
    //                $user['api_key']= $this->generateApiKey();
                    $user_id = $this->user_model->addUser($user);
                    if($user_id){
                        $res = USER_CREATED_SUCCESSFULLY;
                    }else{
                        $res = USER_CREATE_FAILED;
                    }
                }
            }else{
                if($db_user){
    //                if($db_user->fb_token == $user['fb_token'] || $db_user->fb_token==""){
                        $update_user = array(
                            'fb_token' => Input::get('fb_token', ''),
                            'social_type' => Input::get('social_type', ''),
                            'group_id' => Input::get('group_id', ''),
                            'security_question' => Input::get('security_question', ''),
                            'security_answer' => Input::get('security_answer', ''),
                            'email' => Input::get('email', ''),
                            'username' => Input::get('username', ''),
                        );
                        User::where('id', $db_user->id)->update($update_user);
                        $res = USER_CREATED_SUCCESSFULLY;
    //                }else{
    //                    $res = USER_CREATE_FAILED;
    //                }
                }else{
                    $user['created_at'] = date('Y-m-d H:i:s');
                    $user_id = $this->user_model->addUser($user);
                    if($user_id){
                        $res = USER_CREATED_SUCCESSFULLY;
                    }else{
                        $res = USER_CREATE_FAILED;
                    }
                }
                
            }        
            
            
//            $this->data['token'] = $token;
            if ($res == USER_CREATED_SUCCESSFULLY) {
                $this->data["error"] = false;
                $this->data["user"] = User::where('email', Input::get('email'))->first()->toArray();
                unset($this->data['user']['password']);
                unset($this->data['user']['remember_token']);

                $this->updateDeviceToken($this->data["user"]['id']);

                $this->data["message"] = "You are successfully registered";
            } else if ($res == USER_CREATE_FAILED) {
                $this->data["error"] = true;
                $this->data["error_code"] = 2;
                $this->data["message"] = "Oops! An error occurred while registering";
            } else if ($res == USER_ALREADY_EXISTED) {
                $this->data["error"] = true;
                $this->data["error_code"] = 3;
                $this->data["message"] = "Sorry, this email already existed";
            }
        }   
        $this->_JsonOutput();
    }

    public function postLogin(){
        $rules = array(
            'email' => 'required|email',
            'password' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $this->data = array(
                'error' => true,
                'message' => $messages->all(),
            );
        }else{
            $db_user = $this->user_model->getUserByEmail(Input::get('email'));
            $post = array('password'=>Input::get('password'), 'name'=>Input::get('email'));
            if($db_user) {
               if(Hash::check(Input::get('password'), $db_user['password'])){       
                    $this->data["error"] = false;
                    $this->data['user'] = $db_user; 
                    unset($this->data['user']['password']);
                    unset($this->data['user']['remember_token']);
                    
                    $this->updateDeviceToken($db_user['id']);
                } 
                else{
                    $this->data['error'] = true;
                    $this->data['error_code'] = 1;
                    $this->data['message'] = 'Login failed. Incorrect credentials';
                }
            }else{
                $this->data['error'] = true;
                $this->data['error_code'] = 2;
                $this->data['message'] = "You must register to login this app";
            }
        }
        $this->_JsonOutput();
    }
    
    public function postSclogin(){
        $user = array(
            'email' => Input::get('email'),
            'social_type' => Input::get('social_type'),
            'fb_token' => Input::get('fb_token', ''),
        );
            
        $rules = array(
            'email' => 'required|email',
            'social_type' => 'required',
        );
        
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $this->data = array(
                'error' => true,
                'error_code' => 1,
                'message' => implode("\n", $messages->all()),
            );
        }else{
            $db_user = User::where('email', Input::get('email'))
                    ->first();
            if($db_user) {
                $db_user = $db_user->toArray();
                $this->data["error"] = false;
                $this->data["user"] = $db_user;
                unset($this->data['user']['password']);
                unset($this->data['user']['remember_token']);

                $this->updateDeviceToken($this->data["user"]['id']);

                $this->data["message"] = "You are successfully registered";
            }else{
                $this->data['error'] = true;
                $this->data['error_code'] = 2;
                $this->data['message'] = "You must register to login this app";
            }
            
        }   
        $this->_JsonOutput();
    }
    
    public function postTwitterlogin(){
        $user = array(
            'username' => Input::get('username'),
            'social_type' => 'Twitter',
            'fb_token' => Input::get('fb_token', ''),
        );
            
        $rules = array(
            'username' => 'required',
            'fb_token' => 'required',
        );
        
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $this->data = array(
                'error' => true,
                'error_code' => 1,
                'message' => implode("\n", $messages->all()),
            );
        }else{
            $db_user = User::where('username', Input::get('username'))
                    ->first();
            if($db_user) {
                $db_user = $db_user->toArray();
                $this->data["error"] = false;
                $this->data["user"] = $db_user;
                unset($this->data['user']['password']);
                unset($this->data['user']['remember_token']);

                $this->updateDeviceToken($this->data["user"]['id']);

                $this->data["message"] = "You are successfully registered";
            }else{
                $this->data['error'] = true;
                $this->data['error_code'] = 2;
                $this->data['message'] = "You must register to login this app";
            }
        }   
        $this->_JsonOutput();
    }
    
    public function postForgotpassword(){
        $rules = array(
            'email' => 'required',
            'security_question' => 'required',
            'security_answer' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $this->data = array(
                'error' => true,
                'error_code' => 1,
                'message' => $messages->all(),
            );
            $this->_JsonOutput();       
        }
        
        $result = $this->user_model->forgotPassword(Input::get('email'), Input::get('security_question'), Input::get('security_answer'));
        if($result['error'] === true){
            $this->data = array(
                'error' => true,
                'error_code' => 2,
                'message' => $result['message'],
            );
        }else{
            $link = URL::to('reset-password/'.$result['message']);
            $from = "admin@admin.com";
            $params = array(
                'email' => $result['email'],
                'subject' => "Forgot password",
                'message' => "Please reset your password at this link, {$link}",
                'headers' => 'From: '.$from . "\r\n" .
                            'Reply-To: '.$from . "\r\n" .
                            'X-Mailer: PHP/' . phpversion()
            );
            @mail($params['email'], $params['subject'], $params['message'], $params['headers']);
        }
        
        $this->_JsonOutput();
        
    }
    
}


