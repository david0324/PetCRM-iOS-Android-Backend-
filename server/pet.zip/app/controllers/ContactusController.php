<?php

class ContactusController extends BaseController {
    public function __construct(){
        
    }
    
    public function getContactus(){
        $contactus = Contactus::where('user_id', Auth::user()->id)
            ->first();
        if(!$contactus){
            $contactus = array(
                'font' => 'arial',
                'background_color' => '#000826',
                'bodytext_color' => '#000394',
                'bodytext_size' => 'med',
                'bodytext_style' => 'reg',
                'titletext_color' => '#000394',
                'titletext_style' => 'med',
                'field1' => 'first name',
                'required_filed1' => '1',
                'field2' => Input::get('last name', ''),
                'required_filed2' => 1,
                'field3' => 'company',
                'required_filed3' => 1,
                'field4' => 'email',
                'required_filed4' => 1,
                'field5' => 'title',
                'required_filed5' => 1,
                'field6' => 'city',
                'required_filed6' => 1,
                'field7' => 'state',
                'required_filed7' => 1,
                'field8' => 'phone',
                'required_filed8' => 1,
                'field9' => 'comments',
                'required_filed9' => 1,
                'emailto' => Input::get('emailto', ''),
                'confirm_message' => Input::get('confirm_message', ''),
                'user_id' => Auth::user()->id,
            );
        }
            
        if(!Session::has('post'))  {
            Session::flash('post', is_object($contactus)? $contactus->toArray():$contactus);
        }
        return View::make('contactus');
    }
    
    public function contactus(){
        $rules = array(
            'font' => 'required',
        );
                                                  
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        $contactus = array(
            'font' => Input::get('font', ''),
            'background_color' => Input::get('background_color', ''),
            'bodytext_color' => Input::get('bodytext_color', ''),
            'bodytext_size' => Input::get('bodytext_size', ''),
            'bodytext_style' => Input::get('bodytext_style', ''),
            'titletext_color' => Input::get('titletext_color', ''),
            'titletext_style' => Input::get('titletext_style', ''),
            'field1' => Input::get('field1', ''),
            'required_filed1' => Input::get('required_filed1', ''),
            'field2' => Input::get('field2', ''),
            'required_filed2' => Input::get('required_filed2', ''),
            'field3' => Input::get('field3', ''),
            'required_filed3' => Input::get('required_filed3', ''),
            'field4' => Input::get('field4', ''),
            'required_filed4' => Input::get('required_filed4', ''),
            'field5' => Input::get('field5', ''),
            'required_filed5' => Input::get('required_filed5', ''),
            'field6' => Input::get('field6', ''),
            'required_filed6' => Input::get('required_filed6', ''),
            'field7' => Input::get('field7', ''),
            'required_filed7' => Input::get('required_filed7', ''),
            'field8' => Input::get('field8', ''),
            'required_filed8' => Input::get('required_filed8', ''),
            'field9' => Input::get('field9', ''),
            'required_filed9' => Input::get('required_filed9', ''),
            'emailto' => Input::get('emailto', ''),
            'confirm_message' => Input::get('confirm_message', ''),
            'user_id' => Auth::user()->id,
        );
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $db_contactus = Contactus::where('user_id', Auth::user()->id)
                    ->first();
            if($db_contactus){
                Contactus::where('id', $db_contactus->id)->update($contactus);
            }else{
                Contactus::insert($contactus);
            }
        }  
        if($error_messages){
            return Redirect::to('contactus')->with('error_messages', $error_messages)->with('post', $contactus); 
            
        }else{                 
            return Redirect::to('contactus')->with('post', $contactus)->with('success_message', 'Successfully updated.'); 
        }
        
    }

   
}