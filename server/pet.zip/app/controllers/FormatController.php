<?php

class FormatController extends BaseController {
    public function __construct(User $user){
        
    }
    
    public function getFormat(){
        $format = Format::where('user_id', Auth::user()->id)
            ->first();   
        if(!$format){
            $format = array(
                'columns' => 3,
                'font' => 'arial',
                'background_color' => '#000826',
                'bodytext_color' => '#000934',
                'bodytext_size' => 'med',
                'bodytext_style' => 'reg',
                'titletext_color' => '#000934',
                'titletext_style' => 'reg',
                'pricetext_color' => '#000826',
                'pricetext_size' => 'med',
                'pricetext_style' => 'bold',
                'stock_color' => '#000826',
                'stocktext_size' => 'med',
                'stocktext_style' => 'bold',
                'emailseller_link' => 1,
                'emailseller_link_size' => 'med',
                'emailseller_link_color' => '#000826',
                'emailseller_link_text_style' => 'bold',
                'show_shareicon' => 1,
                'shareicon_link' => '',
                'show_facebook' => 1,
                'facebook_link' => '',
                'show_twitter' => 1,
                'twitter_link' => '',
                'show_linkedin' => 1,
                'linkedin_link' => '',
                'show_pinterest' => 1,
                'pinterest_link' => '',
                'itmesperpage' => 30,
                'user_id' => Auth::user()->id,
            );
        }
        if(!Session::has('post'))
            Session::flash('post', is_object($format) ? $format->toArray() : $format);
        return View::make('format')->with('post', $format);                                                   
    }
    
    public function format(){
        $rules = array(
            'columns' => 'required',
            'font' => 'required',
        );
        
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        $format = array(
            'columns' => Input::get('columns', '3'),
            'font' => Input::get('font', 'arial'),
            'background_color' => Input::get('background_color', '#000826'),
            'bodytext_color' => Input::get('bodytext_color', '#000934'),
            'bodytext_size' => Input::get('bodytext_size', 'med'),
            'bodytext_style' => Input::get('bodytext_style', 'reg'),
            'titletext_color' => Input::get('titletext_color', '#000934'),
            'titletext_style' => Input::get('titletext_style', 'reg'),
            'pricetext_color' => Input::get('pricetext_color', '#000826'),
            'pricetext_size' => Input::get('pricetext_size', 'med'),
            'pricetext_style' => Input::get('pricetext_style', 'bold'),
            'stock_color' => Input::get('stock_color', '#000826'),
            'stocktext_size' => Input::get('stocktext_size', 'med'),
            'stocktext_style' => Input::get('stocktext_style', 'bold'),
            'emailseller_link' => Input::get('emailseller_link', 1),
            'emailseller_link_size' => Input::get('emailseller_link_size', ''),
            'emailseller_link_color' => Input::get('emailseller_link_color', ''),
            'emailseller_link_text_style' => Input::get('emailseller_link_text_style', ''),
            'show_shareicon' => Input::get('show_shareicon', 0),
            'shareicon_link' => Input::get('shareicon_link', ''),
            'show_facebook' => Input::get('show_facebook', 0),
            'facebook_link' => Input::get('facebook_link', ''),
            'show_twitter' => Input::get('show_twitter', 0),
            'twitter_link' => Input::get('twitter_link', ''),
            'show_linkedin' => Input::get('show_linkedin', 0),
            'linkedin_link' => Input::get('linkedin_link', ''),
            'show_pinterest' => Input::get('show_pinterest', 0),
            'pinterest_link' => Input::get('pinterest_link', ''),
            'itmesperpage' => Input::get('itmesperpage', ''),
            'user_id' => Auth::user()->id,
        );
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $db_format = Format::where('user_id', Auth::user()->id)
                    ->first();
            if($db_format){
                Format::where('id', $db_format->id)->update($format);
            }else{
                Format::insert($format);
            }
        }  
        if($error_messages){
            return Redirect::to('format')->with('error_messages', $error_messages)->with('post', $format); 
            
        }else{                 
            return Redirect::to('format')->with('post', $format)->with('success_message', 'Successfully updated.'); 
        }
        
    }

   
}