<?php

class UserController extends BaseController {
    public function __construct(User $user){
        $this->user_model = $user;
        $this->group_model = new UserGroup();
        $this->security_model = new Security();
    }

    public function get($id)
    {
        if($id){
            $user = $this->user_model->getUser($id);
        }
        $data['user'] = $user;
        return View::make('useredit', $data);
    }
    
    public function getAll(){
        $users = $this->user_model->getUsers();
        $data['users'] = $users;
        return View::make('userlist', $data);
    }
    
    public function getAdmins(){
        $users = $this->user_model->getUsers(ADMIN_GROUP);
        $data['users'] = $users;
        return View::make('adminlist', $data);
    }
    
    public function getUpdate($id){
        $user = $this->user_model->getUser($id);
        $groups = $this->group_model->getGroups();
        $data = array(
            'post' => (array)$user,
            'groups' => (array)$groups,
            'error_messages' => array(),
        );
        
        return View::make('useredit', $data);
        
    }
    
    public function getAdd(){
        $user = array(
            'username' => '',
            'lastname' => '',
            'company' => '',
            'position' => '',
            'email' => '',
            'password' => '',
            'userGroupId' => '',
        );
        $groups = $this->group_model->getGroups();
        $data = array(
            'post' => $user,
            'groups' => $groups,
            'error_messages' => array(),
        );
//        $this->user_model->addUser($user);
        return View::make('useradd', $data);
    }
    
    public function getDelete($id){
        $id = Request::segment(3);
        $this->user_model->deleteUser($id);
        return Redirect::to('users');
    }

    public function add(){
        $groups = $this->group_model->getGroups();
        $user = array(
            'username' => Input::get('username'),
            'lastname' => Input::get('lastname'),
            'email' => Input::get('email'),
            'company' => Input::get('company'),
            'position' => Input::get('position'),
            'userGroupId' => ADMIN_GROUP,
            'password' => Input::get('password'),
        );
        $rules = array(
            'username' => 'required',
            'email' => 'required',
            'password' => 'required|min:8|confirmed',
            'email' => 'required|email|unique:users'
        );
        $validator = Validator::make(Input::all(), $rules);
        $user['password'] = Hash::make($user['password']);
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $data = array(
                'post' => $user,
                'groups' => $groups,
                'error_messages' => $messages->all(),
            );
            return View::make('useradd', $data);
        }
        $user_id = $this->user_model->addUser($user);
        if($user_id){
            return Redirect::to('users');
        }
    }

    public function update($id){
        $groups = $this->group_model->getGroups();
        $db_user = (array)$this->user_model->getUser($id);
        $user['id'] = $id;
        $user['username'] = Input::get('username');
        $user['email'] = Input::get('email');
        $user['company'] = Input::get('company');
        $user['lastname'] = Input::get('lastname');
        $user['position'] = Input::get('position');
        $user['email'] = Input::get('email');
        $user['userGroupId'] = Input::get('userGroupId');
        
        if(Input::get('password')){
            $user['password'] = Input::get('password');
        }
        $rules = array(
            'username' => 'required',
            'email' => 'required|unique:users,email,'.$id
        );
        if(Input::get('password')){
            $rules['password'] = 'required|min:8|confirmed';
            $user['password'] = Hash::make($user['password']);
        }
        $validator = Validator::make(Input::all(), $rules);
//        echo Hash::check('123456789', $password );exit;
                                  
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $data = array(
                'post' => $user,
                'groups' => $groups,
                'error_messages' => $messages->all(),
            );
            
            return View::make('useredit', $data);
        }
        $user_id = $this->user_model->updateUser($id, $user);

        if($user_id){
            return Redirect::to('user/'.$id)->with('success_message', 'Successfully updated');
        }

    }
    
    public function getLogin(){
        $data = array(
            'post' => array('email'=>''),
            'error_messages' => array()
        );
        return View::make('login', $data);
    }
    
    
    public function login(){    
        $error_messages = array();
        
        $rules = array(
            'password' => 'required|min:8',
            'email' => 'required|email'
        );
        $validator = Validator::make(Input::all(), $rules);
        $post = array('password'=>Input::get('password'), 'email'=>Input::get('email'));
        if(Auth::attempt($post, Input::get('rememberme', false))){
            if(Auth::user()->group_id==2 || Auth::user()->group_id==1){
                return Redirect::intended('/');
            }else{
                Auth::logout();
                $error_messages = array('Your have no permission to access this');
                return Redirect::to('login')->with('error_messages', $error_messages)->with('email', Input::get('email'));
            }
        }else{
            $error_messages = array('Your username/password combination was incorrect');
            return Redirect::to('login')->with('error_messages', $error_messages)->with('email', Input::get('email'));
        }
    }
    
    
    public function getLogout(){
        Auth::logout();
        return Redirect::to('/');
    }
    
    public function getForgotPassword(){
        $data = array(
            'error_messages' => array()
        );
        return View::make('forgot-password', $data);
    }
    
    public function forgotPassword(){
        $rules = array(
            'email' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $result = $this->user_model->forgotPassword(Input::get('email'));
            if($result['error'] === true){
                $error_messages = array($result['message']);
            }else{
                $link = URL::to('reset-password/'.$result['message']);
                $from = "admin@admin.com";
                $params = array(
                    'email' => $result['email'],
                    'subject' => "Forgot password",
                    'message' => "Please reset your password at this link, {$link}",
                    'headers' => 'From: '.$from . "\r\n" .
                                'Reply-To: '.$from . "\r\n" .
                                'X-Mailer: PHP/' . phpversion()
                );
                @mail($params['email'], $params['subject'], $params['message'], $params['headers']);
            }
        }
        if($error_messages){
            return Redirect::to('forgot-password')->with('error_messages', $error_messages)->with('email', Input::get('email')); 
            
        }else{                 
            return Redirect::to('forgot-password')->with('success_message', 'An email was sent to your email address. You can reset your password under the link.'); 
        }
        
    }
    
    public function getResetPassword($forgot_token){
        $data = array(
            'forgot_token' => $forgot_token,
            'error_messages' => array()
        );
        return View::make('reset-password', $data);
    }
    
    
    public function resetPassword($forgot_token){
        $error_messages = array();
        
        $rules = array(
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        $post = array('password'=>Input::get('password'), 'email'=>Input::get('email'));
        if ($validator->fails() || !$forgot_token)
        {
            $error_messages = $validator->messages();
            if(!$forgot_token){
                $error_messages[] = "You have nothing permission to change a password.";
            }
        }else{
            $user = User::where('forgot_token', $forgot_token)->first();
            
            if(!$user){
                $error_messages[] = "You don't have permission to change password.";
                $data = array(
                    'forgot_token' => $forgot_token,
                );
            }else{
                $password = Hash::make(Input::get('password'));
                
                $updatedUser = array(
                    'password' => $password
                );
                
                User::where('id', $user->id)
                    ->update(
                        array(
                            'password' => $password,
                            'forgot_token' => '',
                        )
                    );
           }
        }
        if($error_messages){
            return Redirect::to('reset-password/'.$forgot_token)->with('error_messages', $error_messages); 
            
        }else{                 
            return Redirect::to('login')->with('success_message', 'You successfully reset your password.<br>Please try to login your password.'); 
        }
        
        
    }
    
    public function getForgotPasswordSuccess(){
        return View::make('forgot-password-success');
    }
    public function getRegister(){
        $all_groups = $this->group_model->getGroups();
        $groups = array();
        foreach($all_groups as $group){
            if($group->id==2){
                $groups[] = $group;
            }
        }

        $data = array(
            'error_messages' => array(),
            'user_groups' => $groups,
            'securities' => $this->security_model->getSecurities(),
        );
        unset($data['user_groups'][0]);
        return View::make('register', $data);
    }
    private function generateApiKey() {
        list($usec, $sec) = explode(" ", microtime());
        $microtime = ((float)$usec + (float)$sec);
        return md5($microtime);
    }
    public function register(){
           
        $rules = array(
            'email' => 'required|email',
            'username' => 'required',
            'security_question' => 'required',
            'security_answer' => 'required',
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        );
        
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $user = array(
                'email' => Input::get('email', ''),
                'username' => Input::get('username', ''),
                'group_id' => "2",
                'security_question' => Input::get('security_question', ''),
                'security_answer' => Input::get('security_answer', ''),
                'password' => Input::get('password', ''),
            );
            $db_user = User::where('email', Input::get('email'))
                    ->first();
            if($db_user){
                $res = USER_ALREADY_EXISTED;
            }else{
                $user['password'] = Hash::make($user['password']);
                $user_id = $this->user_model->addUser($user);
                if($user_id){
                    $res = USER_CREATED_SUCCESSFULLY;
                }else{
                    $res = USER_CREATE_FAILED;
                }
            }
            if ($res == USER_CREATE_FAILED) {
                $error_messages[] = "Oops! An error occurred while registereing";
            } else if ($res == USER_ALREADY_EXISTED) {
                $error_messages[] = "Sorry, this name/email already existed";
            }

        }  
        if(!$error_messages){
            $login = array('password'=>Input::get('password'), 'email'=>Input::get('email'));
            Auth::attempt($login,true);
            return Redirect::intended('/');
            
        }else{                 
            return Redirect::to('register')->with('error_messages', $error_messages)->with('post', Input::get()); 
        }
        
    }
    
    public function getProfile(){
        $user = User::where('id', Auth::user()->id)
            ->first();
        $data = array(
            'user' => $user
        );
        return View::make('profile', $data);
    }
    
    public function getSettings(){
        $user = User::where('id', Auth::user()->id)
            ->first();
            
        if(!Session::has('post'))  {
            Session::flash('post', is_object($user)? $user->toArray():$user);
        }
        return View::make('settings');
    }
    
    public function settings(){
        $rules = array(
            'email' => 'required',
            'firstname' => 'required',
            'lastname' => 'required',
            'password' => 'confirmed',
        );
                                                  
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        $user = array(
            'email' => Input::get('email', ''),
            'firstname' => Input::get('firstname', ''),
            'lastname' => Input::get('lastname', ''),
            'id' => Auth::user()->id,
        );
        if(Input::get('password',false) ){
            $user['password'] = Hash::make(Input::get('password'));
        }
        $db_user = User::where('id', '<>', Auth::user()->id)->where('email', $user['email'])
            ->first();
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            if($db_user){
                $error_messages[] = "You can't change to {$user['email']} because the email address is already used by another person.";
            }else{
                User::where('id', Auth::user()->id)
                    ->update(
                        $user
                    )
                ;
            }
        }  
        if($error_messages){
            return Redirect::to('settings')->with('error_messages', $error_messages)->with('post', $user); 
            
        }else{                 
            if($user['email'] != Auth::user()->email || isset($user['password'])){
                Auth::logout();
                return Redirect::to('login')->with('post', $user)->with('success_message', 'Pleas try to login with your updated account. Thank you.'); 
            }else{
                return Redirect::to('settings')->with('post', $user)->with('success_message', 'Successfully updated.'); 
            }
        }
    }
    
//    public function getPagination($totalcount, $page, $countForPage){
//        if($totalcount <= 0){
//            return "";
//        }
//        $totalPages = intval(($totalcount-1) / $countForPage) + 1;
//        $startPage = $page-2;
//        if($startPage <= 0){
//            $startPage = 1;
//        }
//        if($page == 1){
//            $previousHTML = "
//                <li class='disabled'>
//                  <a  aria-label='Previous'>
//                    <span aria-hidden='true'>&laquo;</span>
//                  </a>
//                </li>            
//            ";
//        }else{
//            $targetPage = $page -1;
//            $previousHTML = "
//                <li >
//                  <a href='#' data-page='{$targetPage}' aria-label='Previous'>
//                    <span aria-hidden='true'>&laquo;</span>
//                  </a>
//                </li>            
//            ";
//        }
//        if($page == $totalPages){
//            $nextHTML = "
//                <li class='disabled'>
//                  <a  aria-label='Next'>
//                    <span aria-hidden='true'>&raquo;</span>
//                  </a>
//                </li>
//            ";
//        }else{
//            $targetPage = $page+1;
//            $nextHTML = "
//                <li >
//                  <a href='#' data-page='{$targetPage}' aria-label='Next'>
//                    <span aria-hidden='true'>&raquo;</span>
//                  </a>
//                </li>
//            ";
//        }
//        $liHTML = "";
//        for($i=$startPage; $i<$startPage+5; $i++){
//            if($page == $i){
//                $active = "active";
//            }else{
//                $active = "";
//            }
//            if($i > $totalPages){
//                break;
//            }
//            $liHTML .= "<li class='{$active}'><a data-page='{$i}' href='#'>{$i}</a></li>";
//        }
//        $paginationHTML = "
//            <div class='col-xs-12 text-center'>
//                <nav>
//                  <ul class='pagination'>
//                    {$previousHTML}
//                    {$liHTML}
//                    {$nextHTML}
//                  </ul>
//                </nav>
//            </div>
//        ";
//        
//        return $paginationHTML;
//    }

    
}