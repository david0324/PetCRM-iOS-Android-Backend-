<?php

class FilterController extends BaseController {
    public function __construct(){
        
    }
    
    public function getFilter(){
        $filter = Filter::where('user_id', Auth::user()->id)
            ->first();
        if(!Session::has('post')){
            Session::flash('post', $filter? $filter->toArray():$filter);
        }    
        return View::make('filter');
    }
    
    public function filter(){
        $rules = array(
        );
        
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        $filter = array(
            'year' => Input::get('year', 0),
            'year_from_to_menu' => Input::get('year_from_to_menu', 0),
            'year_fuel_type_menu' => Input::get('year_fuel_type_menu', 0),
            'year_manufacturer_menu' => Input::get('year_manufacturer_menu', 0),
            'capacity' => Input::get('capacity', 0),
            'capacity_any_menu' => Input::get('capacity_any_menu', 0),
            'capacity_type_menu' => Input::get('capacity_type_menu', 0),
            'price' => Input::get('price', 0),
            'price_any_menu' => Input::get('price_any_menu', 0),
            'price_enter_stock' => Input::get('price_enter_stock', 0),
            'price_mast_selector' => Input::get('price_mast_selector', 0),
            'user_id' => Auth::user()->id,
        );
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $db_filter = Filter::where('user_id', Auth::user()->id)
                    ->first();
            if($db_filter){
                Filter::where('id', $db_filter->id)->update($filter);
            }else{
                Filter::insert($filter);
            }
        }  
        if($error_messages){
            return Redirect::to('filter')->with('error_messages', $error_messages)->with('post', $filter); 
            
        }else{                 
            return Redirect::to('filter')->with('post', $filter)->with('success_message', 'Successfully updated.'); 
        }
        
    }

   
}