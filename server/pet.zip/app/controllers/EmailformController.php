<?php

class EmailformController extends BaseController {
    public function __construct(){
        
    }
    
    public function getEmailform(){
        $emailform = Emailform::where('user_id', Auth::user()->id)
            ->first();   
        if(!$emailform){
            $emailform = array(
                'font' => 'arial',
                'background_color' => '#000826',
                'bodytext_color' => '#000394',
                'bodytext_size' => 'med',
                'bodytext_style' => 'reg',
                'titletext_color' => '#000394',
                'titletext_style' => 'reg',
                'email_service' => '',
                'email_service_id' => '',
                'email_service_login' => '',
                'email_service_pass' => '',
                'confirm_message' => '',
                'user_id' => Auth::user()->id,
            );
        }

        if(!Session::has('post'))
            Session::flash('post', is_object($emailform) ? $emailform->toArray() : $emailform);
        return View::make('emailform')->with('post', $emailform);                                                   
    }
    
    public function emailform(){
        $rules = array(
            'font' => 'required',
        );
        
        $validator = Validator::make(Input::all(), $rules);
        $error_messages = array();  
        $emailform = array(
            'font' => Input::get('font', ''),
            'background_color' => Input::get('background_color', ''),
            'bodytext_color' => Input::get('bodytext_color', ''),
            'bodytext_size' => Input::get('bodytext_size', ''),
            'bodytext_style' => Input::get('bodytext_style', ''),
            'titletext_color' => Input::get('titletext_color', ''),
            'titletext_style' => Input::get('titletext_style', ''),
            'email_service' => Input::get('email_service', ''),
            'email_service_id' => Input::get('email_service_id', ''),
            'email_service_login' => Input::get('email_service_login', ''),
            'email_service_pass' => Input::get('email_service_pass', ''),
            'confirm_message' => Input::get('confirm_message', ''),
            'user_id' => Auth::user()->id,
        );
        if ($validator->fails())
        {
            $messages = $validator->messages();
            $error_messages = $messages->all();
        }else{
            $db_emailform = Emailform::where('user_id', Auth::user()->id)
                    ->first();
            if($db_emailform){
                Emailform::where('id', $db_emailform->id)->update($emailform);
            }else{
                Emailform::insert($emailform);
            }
        }  
        if($error_messages){
            return Redirect::to('emailform')->with('error_messages', $error_messages)->with('post', $emailform); 
            
        }else{                 
            return Redirect::to('emailform')->with('post', $emailform)->with('success_message', 'Successfully updated.'); 
        }
        
    }

   
}