<?php

    function PayWithToken($stripeToken, $payment){
        \Stripe\Stripe::setApiKey("sk_test_Sjah1Gaq3XpuwWpBWfTOd1xF");

        // Create the charge on Stripe's servers - this will charge the user's card
        try {
            $charge = \Stripe\Charge::create(array(
              "amount" => $payment, // amount in cents, again
              "currency" => "usd",
              "source" => $stripeToken,
              "description" => "Example charge")
            );
            $result = array(
                'error' => false,
                'result' => json_encode($charge)
            );
        } catch(Exception  $e){
            $result = array(
                'error' => true,
                'message' => $e->getJsonBody()['error']['message'],
            );
        }  
        return $result;
    }
    
