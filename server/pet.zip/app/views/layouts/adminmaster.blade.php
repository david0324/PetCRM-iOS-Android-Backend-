<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>PET @yield('title')</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-touch-fullscreen" content="yes">
        <meta name="author" content="KaijuThemes">

        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600' rel='stylesheet' type='text/css'>
        <link type="text/css" href="{{url('assets/plugins/iCheck/skins/minimal/blue.css')}}" rel="stylesheet">
        <link type="text/css" href="https://cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css" rel="stylesheet">
        <link type="text/css" href="{{url('assets/fonts/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
        <link type="text/css" href="{{url('assets/fonts/themify-icons/themify-icons.css')}}" rel="stylesheet">               
        <link type="text/css" href="{{url('assets/css/custom.css')}}" rel="stylesheet">               
        <link rel="stylesheet" href="{{url('assets/css/styles-alternative.css')}}" id="theme">             
        <link rel="prefetch alternate stylesheet" href="{{url('assets/css/styles.css')}}">                 

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
        <!--[if lt IE 9]>
            <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
            <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- The following CSS are included as plugins and can be removed if unused-->
        
    </head>
    <body class='@yield('body-class')'>
        @if(Auth::check())
            @include('shared.extrabar')
            <div class="extrabar-underlay"></div>
            @include('shared.topnav')
            <div id="wrapper">
                <div id="layout-static">
                    <div class="static-sidebar-wrapper sidebar-bluegray">
                        <div class="static-sidebar">
                            <div class="sidebar">
                                @include('shared.sidebar')
                            </div>                            
                        </div>
                    </div>
                    <div class="static-content-wrapper">
                        <div class="static-content">
                            <div class="page-content">
                                @yield('content')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        @else
            @yield('content')
        @endif
        <script type="text/javascript" src="{{url('assets/js/jquery-1.10.2.min.js')}}"></script>                             <!-- Load jQuery -->
        <script type="text/javascript" src="{{url('assets/js/jqueryui-1.10.3.min.js')}}"></script>                             <!-- Load jQueryUI -->
        <script type="text/javascript" src="{{url('assets/js/bootstrap.min.js')}}"></script>                                 <!-- Load Bootstrap -->
        <script type="text/javascript" src="{{url('assets/js/enquire.min.js')}}"></script>                                     <!-- Load Enquire -->

        <script type="text/javascript" src="{{url('assets/plugins/velocityjs/velocity.min.js')}}"></script>                    <!-- Load Velocity for Animated Content -->
        <script type="text/javascript" src="{{url('assets/plugins/velocityjs/velocity.ui.min.js')}}"></script>

        <script type="text/javascript" src="{{url('assets/plugins/wijets/wijets.js')}}"></script>                             <!-- Wijet -->

        <script type="text/javascript" src="{{url('assets/plugins/codeprettifier/prettify.js')}}"></script>                 <!-- Code Prettifier  -->
        <script type="text/javascript" src="{{url('assets/plugins/bootstrap-switch/bootstrap-switch.js')}}"></script>         <!-- Swith/Toggle Button -->

        <script type="text/javascript" src="{{url('assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js')}}"></script>  <!-- Bootstrap Tabdrop -->

        <script type="text/javascript" src="{{url('assets/plugins/iCheck/icheck.min.js')}}"></script>                         <!-- iCheck -->

        <script type="text/javascript" src="{{url('assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js')}}"></script> <!-- nano scroller -->
        <script type="text/javascript" src="{{url('assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js')}}"></script> <!-- Mousewheel support needed for Mapael -->

        <script type="text/javascript" src="{{url('assets/plugins/sparklines/jquery.sparklines.min.js')}}"></script>              <!-- Sparkline -->
        <script type="text/javascript" src="{{url('assets/js/application.js')}}"></script>       
        <script type="text/javascript" src="{{url('assets/demo/demo.js')}}"></script>
        <script type="text/javascript" src="{{url('assets/demo/demo-switcher.js')}}"></script>         
  
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>

        <script type="text/javascript" src="{{url('assets/js/custom.js')}}"></script> 

    </body>
</html>
