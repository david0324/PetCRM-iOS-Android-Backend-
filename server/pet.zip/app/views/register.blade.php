@extends('layouts.adminmaster')
@section('title', 'Register')
@section('body-class', 'focused-form')

@section('content')
    <div class="container" id="registration-form">
        <a href="{{url('/')}}" class="login-logo"><img src="assets/img/logo-big.png"></a>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h2>Registration Form</h2>
                    </div>
                    <form action="{{url('/register')}}" class="form-horizontal" method="post">
                        <div class="panel-body">
                            <div class="form-group mb-md">
                                <div class="col-xs-12">
                                    @if($error_messages = Session::get('error_messages'))
                                        @foreach($error_messages as $key=>$message)
                                            <div class="alert alert-danger ">{{$message}}</div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="firstname" class="col-xs-4 control-label">Username</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" value="{{Session::get('post')['username']}}" required>
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="password" class="col-xs-4 control-label">Password</label>
                                <div class="col-xs-8">
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="password_confirmation" class="col-xs-4 control-label">Reset Password</label>
                                <div class="col-xs-8">
                                    <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password" required>
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="email" class="col-xs-4 control-label">User Email</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="email" id="email" placeholder="Email" required value="{{Session::get('post')['email']}}">
                                </div>
                            </div>
                            <div class="form-group mb-md hide">
                                <label for="group_id" class="col-xs-4 control-label">Group</label>
                                <div class="col-xs-8">
                                    <select type="text" class="form-control " name="group_id" id="group_id" placeholder="Group" value="">
                                        <option value="">Select One</option>
                                        @foreach($user_groups as $group)
                                            <option value="{{$group->id}}" @if(Session::get('post')['group_id'] == $group->id) selected @endif>{{$group->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="security_question" class="col-xs-4 control-label">Security Question</label>
                                <div class="col-xs-8">
                                    <select type="text" class="form-control" name="security_question" id="security_question" >
                                        <option value="">Security Question</option>
                                        @foreach($securities as $security)
                                            <option value="{{$security->id}}" @if(Session::get('post')['security_question'] == $security->id) selected @endif>{{$security->description}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group mb-md">
                                <label for="security_answer" class="col-xs-4 control-label">Answer</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="security_answer" id="security_answer" placeholder="Answer" required value="{{Session::get('post')['security_answer']}}">
                                </div>
                            </div>
                        
                        </div>
                        <div class="panel-footer">
                            <div class="clearfix">
                                <button type="submit" href="{{asset('register')}}" class="btn btn-primary pull-right">Register</button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>



@stop