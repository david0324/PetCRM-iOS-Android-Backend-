@extends('layouts.adminmaster')

@section('title', 'Detail')
@section('body-class', 'animated-content')
@section('content')
    <ol class="breadcrumb">
        <li class="active"><a href="{{url('')}}">Dashboard</a></li>
    </ol>
    <div class="page-heading">
        <h1>Profile Settings</h1>
    </div>


    <div class="container-fluid">
                                    
        <div class="ui-sortable" data-widget-group="group1">
            <div class="row">
                <div class="col-sm-12">
                    <div style="visibility: visible; opacity: 1; display: block; transform: translateY(0px);" data-widget-static="" class="panel panel-midnightblue" data-widget="{&quot;draggable&quot;: &quot;false&quot;}">
                        <div class="panel-heading">
                            <h2></h2>
                            <!-- <div class="panel-ctrls" data-actions-container="" data-action-collapse='{"target": ".panel-body, .panel-footer"}'></div> -->
                        </div>
                        <form action="{{url('settings')}}" method="post" class="form-horizontal">
                            <div class="panel-body">
                                <div class="form-group mb-md">
                                    <div class="col-xs-12 ">
                                        @if($error_messages = Session::get('error_messages'))
                                            @foreach($error_messages as $key=>$message)
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @endforeach
                                        @endif
                                        @if($success_message = Session::get('success_message'))
                                            <div class="alert alert-success">
                                                {{$success_message}}
                                            </div>
                                        @endif
                                        
                                    </div>
                                </div>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="horizontal-form">
                                        <div class="form-group">
                                            <label for="email" class="col-sm-2 control-label">Email</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="email" name="email" placeholder="Email" type="text" value="{{Session::get('post')['email']}}">
                                            </div>
                                        </div>
                                        <div class="form-group hide">
                                            <label for="firstname" class="col-sm-2 control-label">First name</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="firstname" name="firstname" placeholder="First name" type="text" value="{{Session::get('post')['firstname']}}">
                                            </div>
                                        </div>
                                        <div class="form-group hide">
                                            <label for="lastname" class="col-sm-2 control-label">Last name</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="lastname" name="lastname" placeholder="Last name" type="text" value="{{Session::get('post')['lastname']}}">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="password" class="col-sm-2 control-label">Password</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="password" name="password" placeholder="Password"  value="" type="password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="password_confirmation" class="col-sm-2 control-label">Repeat password</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Repeat password" value="" type="password">
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button class="btn-primary btn">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
    {{Session::forget('post')}}
    
@stop