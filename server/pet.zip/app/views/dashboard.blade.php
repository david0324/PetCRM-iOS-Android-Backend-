@extends('layouts.adminmaster')

@section('title', 'Dashboard')
@section('body-class', 'animated-content')
@section('content')


    <div class="container-fluid">
                                    
        <div class="ui-sortable" data-widget-group="group1">
            <div class="row">
                <div class="col-sm-12">
                        <div class="panel-heading">
                            @if(Auth::user()->group_id == 2)
                                <div class="tax-holder">
                                    <div class="row padding-bottom-30">
                                        <div class="col-xs-12 text-center">
                                            <img width="100px" src="{{url('assets/img/tax-account.png')}}" alt="">
                                        </div>
                                    </div>
                                    <div class="row padding-bottom-30">
                                        <div class="col-xs-6 text-center">
                                            <img width="100px" src="{{url('assets/img/tax-customer.png')}}" alt="">
                                        </div>
                                        <div class="col-xs-6 text-center">
                                            <img width="100px" src="{{url('assets/img/tax-invoice.png')}}" alt="">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-6 text-center">
                                            <img width="100px" src="{{url('assets/img/tax-inbox.png')}}" alt="">
                                        </div>
                                        <div class="col-xs-6 text-center">
                                            <img width="100px" src="{{url('assets/img/tax-appointment.png')}}" alt="">
                                        </div>
                                    </div>
                                </div>
                            @else
                            @endif
                        </div>
                </div>
            </div>

        </div>

    </div>

    
@stop