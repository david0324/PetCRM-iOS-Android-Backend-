@extends('layouts.adminmaster')

@section('title', 'Profile')
@section('body-class', 'animated-content')
@section('content')
    <ol class="breadcrumb">
        <li class="active"><a href="{{url('')}}">Dashboard</a></li>
    </ol>
    <div class="page-heading">
        <h1>Profile</h1>
    </div>

    <div class="container-fluid">
         
        <div data-widget-group="group1">
            <div class="row">
                <div class="col-sm-3">
                    <div class="panel panel-profile">
                      <div class="panel-body">
                        <img src="http://placehold.it/300&text=Placeholder" class="img-circle">
                        <div class="name">{{$user->firstname}} {{$user->lastname}}</div>
                      </div>
                    </div><!-- panel -->
                </div><!-- col-sm-3 -->
                <div class="col-sm-9">
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab-about">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div class="about-area">
                                        <h4>Personal Information</h4>
                                        <div class="table-responsive">
                                          <table class="table about-table">
                                            <tbody>
                                              <tr>
                                                <th width="20%">Full Name</th>
                                                <td>{{$user->firstname}} {{$user->lastname}}</td>
                                              </tr>
                                              <tr>
                                                <th>Email</th>
                                                <td>{{$user->email}}</td>
                                              </tr>
                                              <tr>
                                                <th>Company</th>
                                                <td>{{$user->company}}</td>
                                              </tr>
                                              <tr>
                                                <th>Website</th>
                                                <td>{{$user->website}}</td>
                                              </tr>
                                              <tr>
                                                <th>API Key</th>
                                                <td>{{$user->api_key}}</td>
                                              </tr>
                                              <tr>
                                                <th>Current Partner</th>
                                                @if($user->partner)
                                                    <td>Yes</td>
                                                @else
                                                    <td>No</td>
                                                @endif
                                              </tr>
                                            </tbody>
                                          </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div><!-- .tab-content -->
                </div><!-- col-sm-8 -->
            </div>
        </div>

    </div> <!-- .container-fluid -->

    {{Session::forget('post')}}
    
@stop