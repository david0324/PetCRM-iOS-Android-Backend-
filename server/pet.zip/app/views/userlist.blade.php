@extends('layouts.adminmaster')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <h1 class="pull-left">User List</h1>
        </div>
        <hr/>
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table id="user-list" class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Group</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $key=>$user)
                                <tr>
                                    <td>{{$user->id}}</td>
                                    <td>{{$user->username}}</td>
                                    <td>{{$user->email}}</td>
                                    <td>{{$user->group_name}}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@stop