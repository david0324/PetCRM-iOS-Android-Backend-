<header id="topnav" class="navbar navbar-bluegray navbar-fixed-top">

    <div class="logo-area">
        <span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg">
            <a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
                <span class="icon-bg">
                    <i class="ti ti-shift-left"></i>
                </span>
            </a>
        </span>
        
        <a class="navbar-brand" href="{{url('/')}}">Outline</a>

        <div class="toolbar-icon-bg hidden-xs" id="toolbar-search">
            <div class="input-icon">
                <i class="ti ti-search search"></i>
                <input type="text" placeholder="Type to search..." class="form-control" tabindex="1">
                <i class="ti ti-close remove"></i>
            </div>
        </div>

    </div><!-- logo-area -->






    <ul class="nav navbar-nav toolbar pull-right">



        <li class="dropdown toolbar-icon-bg">
            <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="ti ti-bell"></i></span><span class="badge badge-deeporange">2</span></a>
            <div class="dropdown-menu notifications arrow">
                <div class="topnav-dropdown-header">
                    <span>Notifications</span>
                </div>
            </div>
        </li>

        <li class="dropdown toolbar-icon-bg">
            <a href="#" class="dropdown-toggle" data-toggle='dropdown'><span class="icon-bg"><i class="ti ti-user"></i></span></i></a>
            <ul class="dropdown-menu userinfo arrow">
                <li><a href="{{url('profile')}}"><i class="ti ti-user"></i><span>Profile</span></a></li>
                <li><a href="{{url('settings')}}"><i class="ti ti-settings"></i><span>Settings</span></a></li>
                <li><a href="{{url('logout')}}"><i class="ti ti-shift-right"></i><span>Sign Out</span></a></li>
            </ul>
        </li>

    </ul>

</header>
