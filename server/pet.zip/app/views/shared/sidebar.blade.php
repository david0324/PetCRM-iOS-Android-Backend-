    <div class="widget">
        <div class="widget-body">
            <div class="userinfo">
                <div class="avatar">
                    <img src="{{url('assets/img/user.png')}}" class="img-responsive img-circle"> 
                </div>
                <div class="info">
                    <span class="username">{{Auth::user()->firstname}} {{Auth::user()->lastname}}</span>
                    <span class="useremail">{{Auth::user()->email}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="widget stay-on-collapse" id="widget-sidebar">
        <nav class="widget-body">
            <ul class="acc-menu">
                <li class="nav-separator"><span>Explore</span></li>
                <li ><a href="{{url('/')}}" ><span class="sidebar-icon"><img src="{{url('assets/img/dashboard.png')}}"></span><span>Dashboard</span><span class="badge badge-info"></span></a></li>
                <li><a href="{{url('/users')}}"><i class="ti ti-user"></i><span>Users</span><span class="badge badge-info"></span></a></li>
            </ul>
        </nav>
    </div>


    <!-- <div class="widget" id="widget-sparklines">
        <div class="widget-heading">Sparklines</div>
        <div class="widget-body p-md">
            <div class="clearfix pt-n pb-sm">
                <div class="pull-left"><h5 class="m-n small" style="font-weight: 400;">Total Visitors</h5></div>
                <div class="pull-right"><h5 class="m-n">1,785</h5></div>
            </div>
            <div class="spark-totalvisitors"></div>
            <div class="clearfix pt-lg pb-sm">
                <div class="pull-left"><h5 class="m-n small" style="font-weight: 400;">Total Earnings</h5></div>
                <div class="pull-right"><h5 class="m-n">$7,585</h5></div>
            </div>
            <div class="spark-totalearnings"></div>
        </div>
    </div> -->
