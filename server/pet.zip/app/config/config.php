<?php

return array(

    'upload_dir' => dirname(dirname(__DIR__)).'/html/upload/',
    'number_per_page' => 5,
    'husky_username' => 'adam@eskimo.uk.com',
    'husky_password' => 'password',
	'upload_url' => Asset('upload')."/"

);
