<?php
Route::get('login', array('before' => 'login', 'uses' => 'UserController@getLogin'));
Route::post('login', 'UserController@login');
Route::get('logout', 'UserController@getLogout');
Route::get('register', 'UserController@getRegister');
Route::post('register', 'UserController@register');
Route::get('forgot-password', 'UserController@getForgotPassword');
Route::post('forgot-password', 'UserController@forgotPassword');
Route::get('reset-password/{token}', 'UserController@getResetPassword');
Route::post('reset-password/{token}', 'UserController@resetPassword');

Route::group(array('before' => 'auth'), function(){
    Route::get('/', 'HomeController@index');
    Route::get('profile', 'UserController@getProfile');
    
    Route::get('settings', 'UserController@getSettings');
    Route::post('settings', 'UserController@settings');
    
    Route::get('users', 'UserController@getAll');
});

Route::controller('api', 'APIController');



    