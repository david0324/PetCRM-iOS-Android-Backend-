<?php


class AndroidToken extends Eloquent  {

	protected $table = 'android_tokens';
    
    public static function updateToken($user_id, $token){
        $db_token = AndroidToken::where('user_id', $user_id)
            ->where('token', $token)
            ->first();
        if(!$db_token){
            AndroidToken::insert(
                array(
                    'user_id' => $user_id,
                    'token' => $token,
                )
            );
        }
            
        return true;
    }
}

