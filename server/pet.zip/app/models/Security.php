<?php


class Security extends Eloquent  {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'security';

    public function getSecurities(){
        $query = DB::table($this->table);
        $securities = $query->get();
        return $securities;
    }
    

}