<?php

class Filter extends Eloquent {


	protected $table = 'el_filter';
    

}
