<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users';
	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');
    /**
     * Get the password for the user.
     *
     * @return string
     */

    public function getDates()
    {
        return array();
    }
    public function getAuthPassword()
    {
        return $this->password;
    }

    public function getUsers($group_id=false){
        $query = DB::table($this->table. " as t1");
        $query = $query->leftJoin("user_groups as t2", "t1.group_id", "=", "t2.id");
        if($group_id){
            $query = $query->where('group_id', $group_id);
        }           
        $query = $query->select('t1.*', 't2.name as group_name'); 
        $users = $query->get();
        return $users;
    }
    
    public function addUser($user){
        DB::table($this->table)->insert(
            $user
        );
        $user_id = DB::getPdo()->lastInsertId();
        return $user_id;
    }
    
    public function getUserId($api_key) {
        $query = "SELECT id FROM {$this->table} WHERE api_key = '{$api_key}'";
        
        $user = DB::selectOne($query); 
        return isset($user->id) ? $user->id : 0;
    }
    public function getUserByEmail($email){
        $query = "SELECT t1.*
            FROM {$this->table} t1
            WHERE t1.email = '{$email}'";

        $user = DB::selectOne($query);      
        
        return (array) $user;
    }
    
    public function forgotPassword($email, $security_question, $security_answer){
        $user = User::where('email', $email)
            ->where('security_question', $security_question)
            ->where('security_answer', $security_answer)
            ->first();
        $result = array('error' => false);
        if(!$user){
            $result['error'] = true;
            $result['message'] = 'Invalid user.';
        }else{
            $forgotToken = md5($this->microtime_float().$email);
            User::where('id', $user->id)
                ->update(
                    array(
                        'forgot_token' => $forgotToken
                    )
                );
            $result['message'] = $forgotToken;
            $result['email'] = $user->email;
        }
        return $result;
    }
    
    function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }
    
//-------------------------------------    

}
