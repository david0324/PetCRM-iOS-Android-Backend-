<?php


class Token extends Eloquent  {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'art_token';
    
    public function updateToken($user_id, $token){
        $query = DB::table($this->table);
        $query->where('user_id', $user_id);
        $tokenObj = $query->first();

        $query = DB::table($this->table);
        
        if($tokenObj){
            $query->where('id', $tokenObj->id)
            ->update(array(
                'user_id' => $user_id,
                'token' => $token,
                'timestamp' => time(),
            ));
            
        }else{
            $query->insert(array(
                'user_id' => $user_id,
                'token' => $token,
                'timestamp' => time(),
            ));
        }
    }
    

}