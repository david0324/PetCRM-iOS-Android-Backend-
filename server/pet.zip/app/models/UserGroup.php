<?php


class UserGroup extends Eloquent  {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'user_groups';

    public function getGroups(){
        $query = DB::table($this->table);
        $groups = $query->get();
        return $groups;
    }
    
    public function getGroup($id){
        $query = DB::table($this->table);
        $query->where('id', $id);
        $group = $query->first();
        return $group;
    }
    
    public function addGroup($group){
        DB::table($this->table)->insert(
            $group
        );
        $group_id = DB::getPdo()->lastInsertId();
        return $group_id;
    }
    public function deleteGroup($id){
        $survey = DB::table($this->table)
        ->where('id', '=', $id)
        ->delete();
        return $survey;
    }
    
    public function updateGroup($id, $group){
        DB::table($this->table)
            ->where('id', $id)
            ->update($group);
            
        return $id;
    }
    
    public function reordering($group_id, $a_ordering){
        if($a_ordering<0)
            return;
        DB::table($this->table)
            ->where('id', $group_id)
            ->update(array('ordering'=>$a_ordering));

        $group = $this->getGroup($group_id);
        $groups = $this->getGroups();
        if($a_ordering >= count($groups)){
            $a_ordering = count($groups)-1;
        }
        $flag = false;
        $ordering = 0;
        foreach($groups as $key=>$v){
            if($v->id == $group_id )
                continue;
            if($ordering == $a_ordering){
                $ordering++;
            }
            DB::table($this->table)
                ->where('id', $v->id)
                ->update(array('ordering'=>($ordering)));
            $ordering++;
        }
    }
    

}