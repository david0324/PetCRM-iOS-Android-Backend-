$( document ).ready(function(){
    $('#user-list').DataTable();
})