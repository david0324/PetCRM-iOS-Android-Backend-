//
//  BaseVC.h
//  Dopple
//
//  Created by Mitchell Williams on 21/08/2015.
//  Copyright (c) 2015 Mitchell Williams. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseVC : UIViewController

@end
