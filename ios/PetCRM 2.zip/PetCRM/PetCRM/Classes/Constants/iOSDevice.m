//
//  iOSDevice.m
//  InstaMessenger
//
//  Created by Mitchell Williams on 8/12/15.
//  Copyright (c) 2015 Daniel. All rights reserved.
//

#import "iOSDevice.h"
#import <UIKit/UIKit.h>

@implementation iOSDevice
+ (BOOL)isIphone6
{
    CGSize rectSize = [UIScreen mainScreen].bounds.size;
    return rectSize.width == 375.0f;
}

+ (BOOL)isIphone6Plus
{
    CGSize rectSize = [UIScreen mainScreen].bounds.size;
    return rectSize.width == 414.0f;
}

@end
