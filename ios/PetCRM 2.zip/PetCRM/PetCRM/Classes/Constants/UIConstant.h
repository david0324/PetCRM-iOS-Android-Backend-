//
//  UIConstant.h
//  InstaMessenger
//
//  Created by Mitchell Williams on 8/11/15.
//  Copyright (c) 2015 Daniel. All rights reserved.
//

#ifndef InstaMessenger_UIConstant_h
#define InstaMessenger_UIConstant_h

#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

#pragma mark - Constants
#define SHADOW_COLOR [UIColor colorWithWhite:220.f / 255.f alpha:0.2f]

#pragma mark - Macros
#define STORYBOARD(_name_of_storyboard) [UIStoryboard storyboardWithName:_name_of_storyboard bundle:[NSBundle mainBundle]];

#endif
