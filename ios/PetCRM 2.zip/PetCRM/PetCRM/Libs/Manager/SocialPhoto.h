//
//  SocialPhoto.h
//  YepNoo
//
//  Created by ellisa on 3/16/14.
//  Copyright (c) 2014 Hualong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SocialUser.h"
#import "SocialManager.h"

@interface SocialPhoto : SocialUser
{
    
}

@end
