//
//  SocialPhoto.m
//  YepNoo
//
//  Created by ellisa on 3/16/14.
//  Copyright (c) 2014 Hualong. All rights reserved.
//

#import "SocialPhoto.h"

@implementation SocialPhoto

@end
