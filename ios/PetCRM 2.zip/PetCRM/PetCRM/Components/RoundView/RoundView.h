//
//  RoundView.h
//  Waxara
//
//  Created by Mitchell Williams on 8/11/14.
//  Copyright (c) 2014 Mitchell Williams. All rights reserved.
//

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface RoundView : UIView
{
    UIColor * colorBack;
    
}
@property (nonatomic) IBInspectable int radius;

@end
