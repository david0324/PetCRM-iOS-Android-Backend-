//
//  RoundView.m
//  Waxara
//
//  Created by Mitchell Williams on 8/11/14.
//  Copyright (c) 2014 Mitchell Williams. All rights reserved.
//

#import "RoundView.h"

@implementation RoundView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initView];
    }
    return self;
}

- (id) initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self)
    {
        [self initView];
    }
    return self;
}

- (void) initView
{
    _radius = self.layer.bounds.size.width / 2;
    
    self.layer.cornerRadius = _radius;
    self.layer.masksToBounds = YES;
    self.userInteractionEnabled= YES;

}

-(void) setRadius:(int)radius
{
    _radius = radius;
    
    self.layer.cornerRadius = _radius;
    self.layer.masksToBounds = YES;
    self.userInteractionEnabled= YES;
    
    [self setNeedsDisplay];
}

@end
