//
//  HorizontalPickerView.h
//  FFR
//
//  Created by Mitchell Williams on 6/30/15.
//  Copyright (c) 2015 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KSHorizontalPickerView;

@protocol KSHorizontalPickerViewDataSource <NSObject>
@required
// data source is responsible for reporting how many elements there are
- (NSInteger)numberOfElementsInHorizontalPickerView:(KSHorizontalPickerView *)picker;
@end


@protocol KSHorizontalPickerViewDelegate <NSObject>

@optional
// delegate callback to notify delegate selected element has changed
- (void) horizontalPickerView:(KSHorizontalPickerView *)picker didSelectElementAtIndex:(NSInteger)index;

// one of these two methods must be defined
- (NSString *)horizontalPickerView:(KSHorizontalPickerView *)picker titleForElementAtIndex:(NSInteger)index;
- (UIView *)horizontalPickerView:(KSHorizontalPickerView *)picker viewForElementAtIndex:(NSInteger)index;

@required
// delegate is responsible for reporting the size of each element
- (NSInteger)horizontalPickerView:(KSHorizontalPickerView *)picker widthForElementAtIndex:(NSInteger)index;

@end

@interface KSHorizontalPickerView : UIView <UIScrollViewDelegate>

@property (nonatomic, weak) IBOutlet id <KSHorizontalPickerViewDataSource> dataSource;
@property (nonatomic, weak) IBOutlet id <KSHorizontalPickerViewDelegate> delegate;


@property (nonatomic, readonly) NSInteger numberOfElements;
@property (nonatomic, readonly) NSInteger currentSelectedIndex;

// what font to use for the element labels?
@property (nonatomic, strong) UIFont *elementFont;

// color of labels used in picker
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, strong) UIColor *selectedTextColor; // color of current selected element

// the point, defaults to center of view, where the selected element sits
@property (nonatomic, assign) CGPoint selectionPoint;
@property (nonatomic, strong) UIView *selectionIndicatorView;

// views to display on edges of picker (eg: gradients, etc)
@property (nonatomic, strong) UIView *leftEdgeView;
@property (nonatomic, strong) UIView *rightEdgeView;

// views for left and right of scrolling area
@property (nonatomic, strong) UIView *leftScrollEdgeView;
@property (nonatomic, strong) UIView *rightScrollEdgeView;

// padding for left/right scroll edge views
@property (nonatomic, assign) CGFloat scrollEdgeViewPadding;

@property (nonatomic) BOOL bSetGradient;

- (void)reloadData;
- (void)scrollToElement:(NSInteger)index animated:(BOOL)animate;

@end
