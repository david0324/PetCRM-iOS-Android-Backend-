//
//  UsersPaginator.h
//  sample-chat
//
//  Created by Igor Khomenko on 10/16/13.
//  Copyright (c) 2013 Igor Khomenko. All rights reserved.
//

#import "NMPaginator.h"

@interface UsersPaginator : NMPaginator

@property (nonatomic, strong) NSString* fullName;

@end
