//
//  UsersPaginator.m
//  sample-chat
//
//  Created by Igor Khomenko on 10/16/13.
//  Copyright (c) 2013 Igor Khomenko. All rights reserved.
//

#import "UsersPaginator.h"

@interface UsersPaginator ()

@end

@implementation UsersPaginator

- (void)fetchResultsWithPage:(NSInteger)page pageSize:(NSInteger)pageSize
{
    // Retrieve QuickBlox users
    // 10 users per page
    //
//    QBGeneralResponsePage *responsePage = [QBGeneralResponsePage responsePageWithCurrentPage:page perPage:pageSize];
//    __weak __typeof(self)weakSelf = self;
//    [QBRequest usersForPage:responsePage successBlock:^(QBResponse *response, QBGeneralResponsePage *page, NSArray *users) {
//        
//        [weakSelf receivedResults:users total:page.totalEntries];
//        
//    } errorBlock:^(QBResponse *response) {
//        NSLog(@"%@", response.error);
//    }];
}

- (void)fetchFullNameSearchResultsWithPage:(NSInteger)page pageSize:(NSInteger)pageSize
{
    // Retrieve QuickBlox users
    // 10 users per page
    //
//    QBGeneralResponsePage *responsePage = [QBGeneralResponsePage responsePageWithCurrentPage:page perPage:pageSize];
//    __weak __typeof(self)weakSelf = self;
//    
//    NSString* strSearchText = (self.fullName) ? self.fullName: @"";
//    
//    [QBRequest usersWithFullName:strSearchText page:responsePage successBlock:^(QBResponse *response, QBGeneralResponsePage *page, NSArray *users) {
//        [weakSelf receivedResults:users total:page.totalEntries];
//    } errorBlock:^(QBResponse *response) {
//        NSLog(@"%@", response.error);
//    }];
}




@end
