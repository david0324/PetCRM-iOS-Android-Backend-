//
//  EdgeButton.h
//  Dopple
//
//  Created by Mitchell Williams on 9/10/15.
//  Copyright (c) 2015 Mitchell Williams. All rights reserved.
//

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface EdgeButton : UIButton

@property (nonatomic) IBInspectable float borderWidth;
@property (nonatomic) IBInspectable UIColor* borderColor;

@end
