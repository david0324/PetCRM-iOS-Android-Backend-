//
//  AsynchUIImageView.h
//  Grid
//
//  Created by Mitchell Williams on 1/20/15.
//  Copyright (c) 2015 Grid. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AsynchUIImageView;
@protocol AsynchUIImageViewDelegate <NSObject>

-(void) asynchUIImageViewTapped:(AsynchUIImageView *)imageView;

@end




@interface AsynchUIImageView : UIImageView

@property (nonatomic, retain) id<AsynchUIImageViewDelegate> delegate;
@property (nonatomic) BOOL makeBlurred;

- (void)loadImageFromURLString:(NSString *)theUrlString withDummyImage: (NSString*) dummyImageName;
- (void)loadImageFromURLStringNoCache:(NSString *)theUrlString;
- (void)resetImageView;


@end