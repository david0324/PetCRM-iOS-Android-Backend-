//
//  RoundedUIImageView.h
//  WinSomeThing
//
//  Created by Jameel Khan on 14/11/2012.
//  Copyright (c) 2012 Mobile Media Partners. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsynchRoundedUIImageView.h"
#import <QuartzCore/QuartzCore.h>



@interface CircularUIImageView : AsynchRoundedUIImageView




@end


