//
//  LiveCameraRoundImageView.m
//  Waxara
//
//  Created by Mitchell Williams on 6/13/14.
//  Copyright (c) 2014 Mitchell Williams. All rights reserved.
//

#import "LiveCameraRoundImageView.h"

@implementation LiveCameraRoundImageView
#pragma mark - View Life Cycle
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // Initialization code
        [self initCameraView];
    }
    return self;
}

- (id) init
{
    if (self = [super init])
    {
        [self initCameraView];
    }
    
    return self;
    
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    
    if ((self = [super initWithCoder:aDecoder]))
    {
        [self initCameraView];
    }
    return self;
    
}

#pragma mark - UI Init
- (void) initCameraView
{
    //Make round image view
    self.backgroundColor = [UIColor clearColor];
    
//    CGFloat radius = self.layer.bounds.size.width / 2;
//    
//    self.layer.cornerRadius = radius;
//    self.layer.masksToBounds = YES;
    self.userInteractionEnabled=YES;
    
    //Init Projector View
    if (!self.viewProjector)
    {
        self.viewProjector = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        
        [self addSubview:self.viewProjector];
    }
    
    //Init Captured Image View
    self.imageViewCaptured = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height)];
    
    self.imageViewCaptured.backgroundColor = [UIColor clearColor];
    self.imageViewCaptured.contentMode = UIViewContentModeScaleAspectFit;
    
    //Add captured image view
    [self addSubview:self.imageViewCaptured];
    [self bringSubviewToFront:self.imageViewCaptured];
    
    [self setCaptureViewTransform];
    
    /// made by ping
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];

//    [[NSNotificationCenter defaultCenter]
//     addObserver:self selector:@selector(orientationChanged:)
//     name:UIDeviceOrientationDidChangeNotification
//     object:[UIDevice currentDevice]];
//    
//    [self orientationChanged:nil];
    
    self.nOri = 0;
}


- (void)stopUpdate
{
    if ([self.dvAccelermeter isAccelerometerActive] == YES)
    {
        [self.dvAccelermeter stopAccelerometerUpdates];
    }
    
}

- (void) orientationChanged:(NSNotification *)note
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    
    switch(orientation)
    {
        case UIDeviceOrientationPortrait:
            /* start special animation */
            NSLog(@"UIDeviceOrientationPortrait image");
            // int d = self.nOri;
            if(self.nOri != 3)
            {
                self.viewProjector.transform = CGAffineTransformMakeRotation(DegreesToRadians(90 * 0));
                self.nOri = 3;
            }
            
            break;
            
        case UIDeviceOrientationPortraitUpsideDown:
            /* start special animation */
            NSLog(@"UIDeviceOrientationPortraitUpsideDown image");
            if(self.nOri != 1)
            {
                self.viewProjector.transform = CGAffineTransformMakeRotation(DegreesToRadians(90* 2));
                self.nOri = 1;
            }
            
            break;
        case UIDeviceOrientationLandscapeLeft:
            
            NSLog(@"UIDeviceOrientationLandscapeLeft image");
            if(self.nOri != 2)
            {
                self.viewProjector.transform = CGAffineTransformMakeRotation(DegreesToRadians(90* 3));
                self.nOri = 2;
            }
            
            break;
            
        case UIDeviceOrientationLandscapeRight:
            NSLog(@"UIDeviceOrientationLandscapeRight image");
            if(self.nOri != 0)
            {
                self.viewProjector.transform = CGAffineTransformMakeRotation(DegreesToRadians(90* 1));
                self.nOri = 0;
            }
            
            break;
        default:
            break;
    };
}

- (void) setCaptureViewTransform
{
    UIDevice *currentDevice = [UIDevice currentDevice];
    if ([currentDevice.model rangeOfString:@"Simulator"].location != NSNotFound)
    {
        // running in Simulator
        
        return;
    }
}

#pragma mark - Utility
- (void) setImage: (UIImage*) image
{
    [self stopLiveStreaming];

    self.imageViewCaptured.image = image;

    self.bCaptured = YES;
}

- (void) setStaticImage: (UIImage*) image
{
    [self stopLiveStreaming];
    
    // Resize image
    float fWidth = image.size.width;
    float fHeight = image.size.height;
    
    float fGap = 0.0f;
    CGRect rectCrop;
    
    if (fWidth > fHeight)
    {
        fGap = (fWidth - fHeight) / 2.f;
        rectCrop = CGRectMake(fGap, 0, fHeight, fHeight);
    }
    else
    {
        fGap = (fHeight - fWidth) / 2.f;
        rectCrop = CGRectMake(0, fGap, fWidth, fWidth);
    }
   
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], rectCrop);
    //or use the UIImage wherever you like
    
    UIImage* imageSquare = [UIImage imageWithCGImage:imageRef];
    
    
    self.imageViewCaptured.image = imageSquare;
    
    self.bCaptured = YES;
    
}

- (UIImage*) getImage
{
    return self.imageViewCaptured.image;
}



#pragma mark - Streaming Utility
- (void) startLiveStreaming
{
    if (self.bStreaming || self.bCaptured)
    {
        return;
    }
    
    
    
    self.bStreaming = YES;
    
    self.sessionStreaming = [[AVCaptureSession alloc] init];
    self.sessionStreaming.sessionPreset = AVCaptureSessionPresetPhoto;
    
    AVCaptureVideoPreviewLayer *captureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.sessionStreaming];
    [captureVideoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    
    captureVideoPreviewLayer.frame = self.bounds;
    [self.viewProjector.layer addSublayer:captureVideoPreviewLayer];
    
    UIView *view = self.viewProjector;
    CALayer *viewLayer = [view layer];
    [viewLayer setMasksToBounds:YES];
    
    CGRect bounds = [view bounds];
    [captureVideoPreviewLayer setFrame:bounds];
    
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    AVCaptureDevice *frontCamera = nil;
    AVCaptureDevice *backCamera = nil;
    
    for (AVCaptureDevice *device in devices)
    {
        NSLog(@"Device name: %@", [device localizedName]);
        if ([device position] == AVCaptureDevicePositionBack)
        {
            NSLog(@"Device position : back");
            backCamera = device;
        }
        else
        {
            NSLog(@"Device position : front");
            frontCamera = device;
        }
    }
    
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:frontCamera error:&error];
    if (!input) {
        NSLog(@"ERROR: trying to open camera: %@", error);
    }
    
    if (input)
    {
        [self.sessionStreaming addInput:input];
        
        self.outputStillImage = [[AVCaptureStillImageOutput alloc] init];
        NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys: AVVideoCodecJPEG, AVVideoCodecKey, nil];
        [self.outputStillImage setOutputSettings:outputSettings];
        
        [self.sessionStreaming addOutput:self.outputStillImage];
        
        [self.sessionStreaming startRunning];
    }
    else
    {
        self.imageViewCaptured.image = [UIImage imageNamed:@"Profile Photo"];
        self.bCaptured = YES;
        self.bStreaming = NO;
    }
    
    
}

- (void) stopLiveStreaming
{
    if (!self.bStreaming)
    {
        return;
    }
    
    self.bStreaming = NO;
    
    [self.sessionStreaming stopRunning];
}

- (void) refreshLiveCamera
{
    self.imageViewCaptured.image = nil;
    
    self.bStreaming = NO;
    self.bCaptured = NO;
    
    [self startLiveStreaming];
}

- (void) captureLiveCamera: (LCRCompletion) blockCompletion
{
    if (self.bCaptured)
    {
        return;
    }
    
    
    AVCaptureConnection *videoConnection = nil;
    for (AVCaptureConnection *connection in self.outputStillImage.connections) {
        
        for (AVCaptureInputPort *port in [connection inputPorts]) {
            
            if ([[port mediaType] isEqual:AVMediaTypeVideo] ) {
                videoConnection = connection;
                break;
            }
        }
        
        if (videoConnection) {
            break;
        }
    }
    
    
    
    NSLog(@"about to request a capture from: %@", self.outputStillImage);
    
    
    [self.outputStillImage captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler: ^(CMSampleBufferRef imageSampleBuffer, NSError *error) {
        
        if (error)
        {
            blockCompletion(NO);
        }
        else
        {
            if (imageSampleBuffer != NULL) {
                NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageSampleBuffer];
                
                [self stopLiveStreaming];
                
                [self processImage:[UIImage imageWithData:imageData]];
                //
                //            UIImage* imageTemp = [UIImage imageWithData:imageData];
                //            imageTemp = [self imageRotatedByDegrees:90 image:imageTemp];
                //            self.imageViewCaptured.image = imageTemp;
                
                blockCompletion(YES);
                
                self.bCaptured = YES;
            
        }
        }
    }];
    
    
    
}


- (void) processImage:(UIImage *)image
{ //process captured image, crop, resize and rotate
    
    if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad)
    { //Device is ipad
        // Resize image
        UIGraphicsBeginImageContext(CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT - 20));
        [image drawInRect: CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 20)];
        UIImage *smallImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        CGRect cropRect = CGRectMake(0, 130, 768, 768);
        CGImageRef imageRef = CGImageCreateWithImageInRect([smallImage CGImage], cropRect);
        //or use the UIImage wherever you like
        
        UIImage* flippedImage = [UIImage imageWithCGImage:imageRef];
        
        if (([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft) || ([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeRight))
        {
            flippedImage = [self imageRotatedByDegrees:90 image:flippedImage];
        }
        
        flippedImage = [UIImage imageWithCGImage:flippedImage.CGImage
                                            scale:flippedImage.scale
                                      orientation:UIImageOrientationUpMirrored];

        
        [self.imageViewCaptured setImage:flippedImage];
        
        CGImageRelease(imageRef);
        
    }
    else
    { //Device is iphone
        // Resize image
        NSLog(@"image size: %f * %f", image.size.width, image.size.height);
        
        CGFloat scale = image.size.width / [[UIScreen mainScreen] bounds].size.width;
        
        CGFloat newWidth = image.size.width / scale;
        CGFloat newHeight = image.size.height / scale;
        
        NSLog(@"new image size: %f * %f", newWidth, newHeight);
        
        UIGraphicsBeginImageContext(CGSizeMake(newWidth, newHeight));
        [image drawInRect: CGRectMake(0, 0, newWidth, newHeight)];
        UIImage *smallImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        CGFloat nImageWidth = (newHeight > newWidth) ? newWidth: newHeight;
        
        CGRect cropRect = CGRectMake((newWidth - nImageWidth) / 2.0f, (newHeight - nImageWidth) / 2.0f, nImageWidth, nImageWidth);
        
        CGImageRef imageRef = CGImageCreateWithImageInRect([smallImage CGImage], cropRect);
        
        UIImage* flippedImage = [UIImage imageWithCGImage:[[UIImage imageWithCGImage:imageRef] CGImage]
                                                    scale:[UIImage imageWithCGImage:imageRef].scale orientation: UIImageOrientationUpMirrored];
//        UIImage* flippedImage = [UIImage imageWithCGImage:image.CGImage
//                                                    scale:image.scale orientation: UIImageOrientationUpMirrored];

        
        if (([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft) || ([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeRight))
        {
            flippedImage = [self imageRotatedByDegrees:0 image:flippedImage];
        }
        
        self.imageCaptured = flippedImage;
//        [self.imageViewCaptured setImage:flippedImage];
        
//        CGImageRelease(imageRef);
    }
    
}

- (UIImage *)imageRotatedByDegrees:(CGFloat)degrees image: (UIImage*) image
{
    // calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,image.size.width, image.size.height)];
    
    CGAffineTransform t = CGAffineTransformMakeRotation(DegreesToRadians(degrees));
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    
    // Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    // Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    //   // Rotate the image context
    CGContextRotateCTM(bitmap, DegreesToRadians(degrees));
    
    // Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-image.size.width / 2, -image.size.height / 2, image.size.width, image.size.height), [image CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
    
}

@end
