//
//  LiveCameraRoundImageView.h
//  Waxara
//
//  Created by Mitchell Williams on 6/13/14.
//  Copyright (c) 2014 Mitchell Williams. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMotion/CoreMotion.h>
#import <CoreMotion/CMAccelerometer.h>
#import <UIKit/UIAccelerometer.h>
#define DegreesToRadians(x) ((x) * M_PI / 180.0f)



typedef void(^LCRCompletion)(BOOL);

@interface LiveCameraRoundImageView : UIView<UIAccelerometerDelegate>



@property (nonatomic, strong) UIImageView* imageViewCaptured;
@property (nonatomic, retain) AVCaptureStillImageOutput* outputStillImage;
@property (nonatomic, retain) AVCaptureSession *sessionStreaming;
@property (nonatomic, strong) UIView* viewProjector;
@property (nonatomic, strong) UIImage* imageCaptured;

@property (nonatomic) BOOL bStreaming;
@property (nonatomic) BOOL bCaptured;
// by ping
@property int nOri;
@property (nonatomic, strong) CMMotionManager *dvAccelermeter;
//
//Return captured uiimage
- (void) captureLiveCamera: (LCRCompletion) blockCompletion;
- (void) refreshLiveCamera;

- (void) setImage: (UIImage*) image;

- (void) setStaticImage: (UIImage*) image;
- (UIImage*) getImage;

//Start and Stop streaming
- (void) startLiveStreaming;
- (void) stopLiveStreaming;

- (void) setCaptureViewTransform;

@end
