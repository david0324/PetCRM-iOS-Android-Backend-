//
//  RoundBorderView.h
//  FFR
//
//  Created by Mitchell Williams on 7/3/15.
//  Copyright (c) 2015 MK. All rights reserved.
//

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface RoundBorderView : UIView

@property (nonatomic) IBInspectable int radius;
@property (nonatomic) IBInspectable float borderWidth;
@property (nonatomic) IBInspectable UIColor* borderColor;


@end
