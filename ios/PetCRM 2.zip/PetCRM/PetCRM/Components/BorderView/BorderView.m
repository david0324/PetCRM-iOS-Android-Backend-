//
//  BorderView.m
//  FFR
//
//  Created by Mitchell Williams on 6/30/15.
//  Copyright (c) 2015 MK. All rights reserved.
//

#import "BorderView.h"

@implementation BorderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initView];
    }
    return self;
}

- (id) initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self)
    {
        [self initView];
    }
    return self;
}

- (void) initView
{
    _borderWidth = 1;
    _borderColor = [UIColor clearColor];
    
    self.layer.borderColor = [_borderColor CGColor];
    self.layer.borderWidth = _borderWidth;
    
    self.layer.masksToBounds = YES;
    self.userInteractionEnabled= YES;
    
}

- (void) setBorderWidth:(float)borderWidth
{
    _borderWidth = borderWidth;
    
    self.layer.borderColor = [_borderColor CGColor];
    self.layer.borderWidth = _borderWidth;

    self.layer.masksToBounds = YES;
    self.userInteractionEnabled= YES;
    
    [self setNeedsDisplay];
}

- (void) setBorderColor:(UIColor *)borderColor
{
    _borderColor = borderColor;
    
    self.layer.borderColor = [_borderColor CGColor];
    self.layer.borderWidth = _borderWidth;
    
    self.layer.masksToBounds = YES;
    self.userInteractionEnabled= YES;

}

@end
