//
//  AppConstant.h
//  Dopple
//
//  Created by Mitchell Williams on 21/08/2015.
//  Copyright (c) 2015 Mitchell Williams. All rights reserved.
//

#ifndef Dopple_AppConstant_h
#define Dopple_AppConstant_h

#pragma mark - Notifications
#define kNotifSignOut                   @"signout"
#define kNotifLogin                     @"trylogin"

#define kNotifShowMBProgressBar         @"showProgress"
#define kNotifHideMBProgressBar         @"hideProgress"

#define kNotifGoMainScreen              @"gomainscreen"

#define kNotifGotCandidates             @"gotCandidates"
#define kNotifGotImageFromUser          @"gotimagefromuser"
#define kNotifShowPostTextView          @"showposttextview"
#define kNotifShowImagePickerVC         @"showimagepickervc"
#define kNotifGotNewAvatar              @"gotnewavatar"

#pragma mark - Constants
#define kLoggedIn                       @"loggedin"
#define kFullName                       @"fullname"
#define kUserId                         @"userid"
#define kPassword                       @"password"
#define kToken                          @"token"
#define kAvatarUrl                      @"avatarurl"
#define kSelPhotoUrl                    @"selphotourl"
#define kSelEmail                       @"selEmail"
#define kQustion                        @"question"
#define kDoppleUsers                    @"doppleusers"
#define kEnrolledUsers                  @"enrolledusers"
#define kUserPhoto                      @"userphoto"
#define kUserInfo                       @"userinfo"
#define kConnectedFB                    @"connectfb"
#define kConnectedTwitter               @"connecttwitter"
#define kTurnOnPN                       @"turnonpn"
#define kLogout                         @"logout"
#define kEnrolled                       @"enrollface"
#define kDoppleTemp                     @"tempuser"


#pragma mark - Segues
#define kSegueLogin                     @"LoginSegue"
#define kSegueMainPage                  @"MainPageSegue"



#pragma mark - Facebook 
#define kFBAppId                        @"1666045276971271"

#pragma mark - Twitter
#define TwitterConsumerKey              @"kbkVuDHyN24kafcL1R5Kxfn72"
#define TwitterConsumerSecret           @"NfBbaXUKnIQ5GbOK4MGBpPvDmwwBErGDbPfIMClHnMcZTTrj1f"

#pragma mark - Google Pluse
#define GooglePluseClientID             @"142580359742-4t4s7d8ks47sdjlt7p3jc6ssd70ppg4k.apps.googleusercontent.com"

#pragma mark - Dopple Manager
#define URL_IMAGE_SEARCH                @"https://www.google.com/searchbyimage?&image_url="
#define URL_SEARCH_DOPPLE(_ImageUrl)    [NSString stringWithFormat:@"%@%@", URL_IMAGE_SEARCH, _ImageUrl]


#define API_BASE_PHOTO_URL                    @"http://212.227.84.242/backend/uploads/profile/"
//#define API_BASE_PHOTO_URL                    @"http://10.0.1.71/backend/uploads/profile/"

#endif
