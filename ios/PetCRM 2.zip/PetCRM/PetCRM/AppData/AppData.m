//
//  AppData.m
//  Dopple
//
//  Created by Mitchell Williams on 21/08/2015.
//  Copyright (c) 2015 Mitchell Williams. All rights reserved.
//

#import "AppData.h"

@implementation AppData

#pragma mark - Initialization
+ (AppData*) sharedData
{
    static AppData *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[[self class] alloc]init];
    });
    return sharedInstance;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        
    }
    
    return self;
}

#pragma mark - Getter and Setter

- (void) setDicUserInfo:(NSMutableDictionary *)dicUserInfo
{
    [[NSUserDefaults standardUserDefaults] setValue:dicUserInfo forKey:kUserInfo];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableDictionary*) dicUserInfo
{
    NSMutableDictionary* dicTemp = [NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults] valueForKey:kUserInfo]];
    
    return dicTemp;
}

- (void) setImageUser:(NSData *)imageUserData
{
    NSData* myEncodedImageData = [NSKeyedArchiver archivedDataWithRootObject:imageUserData];
    [[NSUserDefaults standardUserDefaults] setObject:myEncodedImageData forKey:kUserPhoto];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}
    

- (NSData*) imageUserData
{
    NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults] objectForKey:kUserPhoto];
    NSData* dataImage = [NSKeyedUnarchiver unarchiveObjectWithData:myEncodedImageData];
    return dataImage;
}

- (void) setArrDoppleUsers:(NSMutableArray *)arrDoppleUsers
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:arrDoppleUsers];
    
    [[NSUserDefaults standardUserDefaults] setObject:encodedObject forKey:kDoppleUsers];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableArray*) arrDoppleUsers
{
    NSData *encodedObject = [[NSUserDefaults standardUserDefaults] objectForKey:kDoppleUsers];
    
    NSArray* arrTemp = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
    
    NSMutableArray* arrResult = nil;
    if (!arrTemp)
    {
        arrResult = [NSMutableArray new];
    }
    else
    {
        arrResult = [[NSMutableArray alloc] initWithArray:arrTemp];
    }
    
    return arrResult;

}

- (void) setArrEnrolledUsers:(NSMutableArray *)arrEnrolledUsers
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:arrEnrolledUsers];
    
    [[NSUserDefaults standardUserDefaults] setObject:encodedObject forKey:kEnrolledUsers];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableArray*) arrEnrolledUsers
{
    NSData *encodedObject = [[NSUserDefaults standardUserDefaults] objectForKey:kEnrolledUsers];
    
    NSArray* arrTemp = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
    
    NSMutableArray* arrResult = nil;
    if (!arrTemp)
    {
        arrResult = [NSMutableArray new];
    }
    else
    {
        arrResult = [[NSMutableArray alloc] initWithArray:arrTemp];
    }
    
    return arrResult;
    
}

- (void) setArrQuestion:(NSMutableArray *)arrQuestion
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:arrQuestion];
    
    [[NSUserDefaults standardUserDefaults] setObject:encodedObject forKey:kQustion];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableArray*) arrQuestion
{
    NSData *encodedObject = [[NSUserDefaults standardUserDefaults] objectForKey:kQustion];
    
    NSArray* arrTemp = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
    
    NSMutableArray* arrResult = nil;
    if (!arrTemp)
    {
        arrResult = [NSMutableArray new];
    }
    else
    {
        arrResult = [[NSMutableArray alloc] initWithArray:arrTemp];
    }
    
    return arrResult;
}

- (void) setArrDoppleTemp:(NSMutableArray *)arrDoppleTemp
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:arrDoppleTemp];
    
    [[NSUserDefaults standardUserDefaults] setObject:encodedObject forKey:kDoppleTemp];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableArray*) arrDoppleTemp
{
    NSData *encodedObject = [[NSUserDefaults standardUserDefaults] objectForKey:kDoppleTemp];
    
    NSArray* arrTemp = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
    
    NSMutableArray* arrResult = nil;
    if (!arrTemp)
    {
        arrResult = [NSMutableArray new];
    }
    else
    {
        arrResult = [[NSMutableArray alloc] initWithArray:arrTemp];
    }
    
    return arrResult;
}



- (void) setStrFullName:(NSString *)strFullName
{
    [[NSUserDefaults standardUserDefaults] setValue:strFullName forKey:kFullName];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strFullName
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kFullName];
}

- (void) setStrToken:(NSString *)strToken
{
    [[NSUserDefaults standardUserDefaults] setValue:strToken forKey:kToken];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strToken
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kToken];
}

- (void) setStrAvatarUrl:(NSString *)strAvatarUrl
{
    [[NSUserDefaults standardUserDefaults] setValue:strAvatarUrl forKey:kAvatarUrl];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strAvatarUrl
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kAvatarUrl];
}

- (void) setStrSelPhotoUrl:(NSString *)strSelPhotoUrl
{
    [[NSUserDefaults standardUserDefaults] setValue:strSelPhotoUrl forKey:kAvatarUrl];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strSelPhotoUrl
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kAvatarUrl];
}

- (void) setStrSelEmail:(NSString *)strSelEmail
{
    [[NSUserDefaults standardUserDefaults] setValue:strSelEmail forKey:kSelEmail];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strSelEmail
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kSelEmail];
}

- (void) setStrUserId:(NSString *)strUserId
{
    [[NSUserDefaults standardUserDefaults] setValue:strUserId forKey:kUserId];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strUserId
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kUserId];
}

- (void) setStrPassword:(NSString *)strPassword
{
    [[NSUserDefaults standardUserDefaults] setValue:strPassword forKey:kPassword];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString*) strPassword
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:kPassword];
}

- (void) setBLoggedIn:(BOOL)bLoggedIn
{
    if (!bLoggedIn)
    {
        [AppData sharedData].strUserId = @"";
        [AppData sharedData].strFullName = @"";
        [AppData sharedData].strPassword = @"";
        [AppData sharedData].strToken = @"";
        [AppData sharedData].strAvatarUrl = @"";
        [AppData sharedData].strSelPhotoUrl = @"";
    }
    
    [[NSUserDefaults standardUserDefaults] setBool:bLoggedIn forKey:kLoggedIn];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL) bLoggedIn
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kLoggedIn];
}

- (void) setBConnectedFB:(BOOL)bConnectedFB
{
    [[NSUserDefaults standardUserDefaults] setBool:bConnectedFB forKey:kConnectedFB];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL) bConnectedFB
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kConnectedFB];
}

- (void) setBConnectedTwitter:(BOOL)bConnectedTwitter
{
    [[NSUserDefaults standardUserDefaults] setBool:bConnectedTwitter forKey:kConnectedTwitter];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL) bConnectedTwitter
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kConnectedTwitter];
}

- (void) setBTurnedOnPN:(BOOL)bTurnedOnPN
{
    [[NSUserDefaults standardUserDefaults] setBool:bTurnedOnPN forKey:kTurnOnPN];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL) bTurnedOnPN
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kTurnOnPN];
}

- (void) setBLogOut:(BOOL)bLogOut
{
    [[NSUserDefaults standardUserDefaults] setBool:bLogOut forKey:kLogout];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL) bLogOut
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kLogout];
}

- (BOOL) bEnrolled
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kEnrolled];
}

- (void) setBEnrolled:(BOOL)bEnrolled
{
    [[NSUserDefaults standardUserDefaults] setBool:bEnrolled forKey:kEnrolled];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void) setNFaceNum:(int) nFace {
    [[NSUserDefaults standardUserDefaults] setInteger:nFace forKey:@"enrolledfacenum"];
}

- (int) nFaceNum {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"enrolledfacenum"];
}

- (void) setBFromFriend:(BOOL)bFromFriend {
    [[NSUserDefaults standardUserDefaults] setInteger:bFromFriend forKey:@"fromfriend"];
}

- (BOOL) bFromFriend {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"fromfriend"];
}


- (void) setNSelIdx:(int)nSelIdx {
    [[NSUserDefaults standardUserDefaults] setInteger:nSelIdx forKey:@"selectedindex"];
}

- (int) nSelIdx {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"selectedindex"];
}

- (int) nIdxFaceInArr {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"faceidxinarr"];
}

- (void) setNIdxFaceInArr:(int)nIdxFaceInArr {
    [[NSUserDefaults standardUserDefaults] setInteger:nIdxFaceInArr forKey:@"faceidxinarr"];
}

- (void) setNIdxInGroup:(int) nIdxInGroup {
    [[NSUserDefaults standardUserDefaults] setInteger:nIdxInGroup forKey:@"idxingroup"];
}

- (int) nIdxInGroup {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"idxingroup"];
}

- (void) setNStatus:(int)nStatus {
    [[NSUserDefaults standardUserDefaults] setInteger:nStatus forKey:@"status"];
}

- (int) nStatus {
    return [[NSUserDefaults standardUserDefaults] integerForKey:@"status"];
}


@end
