//
//  AppData.h
//  Dopple
//
//  Created by Mitchell Williams on 21/08/2015.
//  Copyright (c) 2015 Mitchell Williams. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppData : NSObject

+ (AppData*) sharedData;

@property (nonatomic) BOOL bLoggedIn;


//User Info
@property (nonatomic, retain) NSString* strUserId;
@property (nonatomic, retain) NSString* strFullName;
@property (nonatomic, retain) NSString* strPassword;
@property (nonatomic, retain) NSString* strToken;
@property (nonatomic, retain) NSString* strAvatarUrl;
@property (nonatomic, retain) NSString* strSelPhotoUrl;
@property (nonatomic, retain) NSString* strSelEmail;

@property (nonatomic, retain) NSMutableDictionary* dicUserInfo;

@property (nonatomic, retain) NSMutableArray* arrQuestion;

@property (nonatomic, retain) NSMutableArray* arrUserList;

@property (nonatomic, retain) NSMutableArray* arrDoppleUsers;

@property (nonatomic, retain) NSMutableArray* arrEnrolledUsers;

@property (nonatomic, retain) NSMutableArray* arrDoppleTemp;

@property (nonatomic, retain) NSData* imageUserData;

//Settings
@property (nonatomic) BOOL bConnectedFB;
@property (nonatomic) BOOL bConnectedTwitter;
@property (nonatomic) BOOL bTurnedOnPN;
@property (nonatomic) BOOL bEnrolled;
@property (nonatomic) BOOL bActivity;
@property (nonatomic) BOOL bLogOut;
@property (nonatomic) BOOL bFromFriend;
@property (nonatomic) int  nFaceNum;
@property (nonatomic) int  nIdxInGroup;
@property (nonatomic) int  nStatus;
@property (nonatomic) int  nIdxFaceInArr;
@property (nonatomic) int  nSelIdx;

//Push Notification
@property (nonatomic, retain) NSData* deviceToken;

typedef enum {
    SIGNUP = 0,
    LOGINWITHEMAIL,
    LOGINWITHFACEBOOK,
    RETAKE,
    SPLASH
}STATUS;

@end
