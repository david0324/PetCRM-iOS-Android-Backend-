//
//  RegisterVC.m
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "RegisterVC.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <GoogleOpenSource/GoogleOpenSource.h>
#import "SocialManager.h"
#import "MainWorkVC.h"
#import "TaxiVC.h"

@implementation RegisterVC

@synthesize txtUsername, txtPassword, txtEmail, txtSelectOne, txtSecretQuestion, txtAnswer, registerView;

- (void) viewDidLoad {
    [super viewDidLoad];
    
    [self setTextFieldProperty];
    
    plusService = [[GTLServicePlus alloc] init];
    plusService.retryEnabled = YES;
    arrGroupName = [[NSMutableArray alloc] init];
    arrQuestion = [[NSMutableArray alloc] init];
    arrGroupID = [[NSMutableArray alloc] init];
    arrQuestionID = [[NSMutableArray alloc] init];
    [self getSecurityQuestion];
    bSocial = NO;
    socialType = @"";
    fbtokenId = @"";
}

- (void) setTextFieldProperty {
    
    [txtUsername setDelegate:self];
    [txtUsername setTintColor:[UIColor blackColor]];
    txtUsername.keyboardType = UIKeyboardTypeDefault;
    
    [txtPassword setDelegate:self];
    [txtPassword setTintColor:[UIColor blackColor]];
    txtPassword.keyboardType = UIKeyboardTypeDefault;
    [txtPassword setSecureTextEntry:YES];

    [txtEmail setDelegate:self];
    [txtEmail setTintColor:[UIColor blackColor]];
    txtEmail.keyboardType = UIKeyboardTypeEmailAddress;
    
    [txtSelectOne setDelegate:self];
    [txtSelectOne setTintColor:[UIColor blackColor]];
    txtSelectOne.keyboardType = UIKeyboardTypeDefault;
    txtSelectOne.tag = 422;
    
    [txtSecretQuestion setDelegate:self];
    [txtSecretQuestion setTintColor:[UIColor blackColor]];
    txtSecretQuestion.keyboardType = UIKeyboardTypeDefault;
    txtSecretQuestion.tag = 727;
    
    [txtAnswer setDelegate:self];
    [txtAnswer setTintColor:[UIColor blackColor]];
    txtAnswer.keyboardType = UIKeyboardTypeDefault;
}

-(void)initDropdown {
    dropDownGroup = [[DropDownView alloc] initWithArrayData:arrGroupName cellHeight:30 heightTableView:30 * 3 paddingTop:-8 paddingLeft:-5 paddingRight:-10 refView:txtSelectOne animation:BLENDIN openAnimationDuration:0 closeAnimationDuration:0];
    
    dropDownQuestion = [[DropDownView alloc] initWithArrayData:arrQuestion cellHeight:30 heightTableView:30 * 2 paddingTop:-8 paddingLeft:-5 paddingRight:-10 refView:txtSecretQuestion animation:BLENDIN openAnimationDuration:0 closeAnimationDuration:0];

    
    dropDownGroup.delegate_ = self;
    dropDownQuestion.delegate_ = self;
    
    [registerView addSubview:dropDownGroup.view];
    [registerView addSubview:dropDownQuestion.view];
    
}

-(BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

- (BOOL) canSubmit
{
    BOOL bResult = YES;
    
    if (txtEmail.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtUsername.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the secret question." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtPassword.text.length < 3 && bSocial == NO)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the answer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtSelectOne.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the answer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtSecretQuestion.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the answer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtAnswer.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the answer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
    }

    
    if (![self validateEmail:txtEmail.text]){
        
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter valid Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        return NO;
    }
    
    return bResult;
}

- (void)getSecurityQuestion {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@",_responseObject);
        [[AppData sharedData].arrQuestion removeAllObjects];
        
        NSMutableDictionary* questionDic = (NSMutableDictionary*)_responseObject;
        
        //[arrGroupName addObject:@"Select one..."];
        groupDic = [questionDic objectForKey:@"groups"];
        for (NSDictionary* dic in groupDic) {
            NSString* strGroupName = [dic objectForKey:@"name"];
            [arrGroupName addObject:strGroupName];
            NSString* strId = [dic objectForKey:@"id"];
            [arrGroupID addObject:strId];
        }
        
        NSMutableArray* arrQuestionDic = [questionDic objectForKey:@"securities"];
        for (NSDictionary* dic in arrQuestionDic) {
            NSString* strDescription = [dic objectForKey:@"description"];
            [arrQuestion addObject:strDescription];
            [arrQuestionID addObject:[dic objectForKey:@"id"]];
        }
        
        [AppData sharedData].arrQuestion = arrQuestion;
        [self initDropdown];
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] GetSecurityQuestion:@""
                                  successed:successed
                                    failure:failure];
}

- (IBAction)gotoBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

#pragma mark-registerWithEmail
- (IBAction)gotoSubmit:(id)sender {
    if ([self canSubmit]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        void (^successed)(id _responseObject) = ^(id _responseObject)
        {
            if ([_responseObject isEqual:nil])
            {
                [self showAlertTips:@"Connection Problem"];
                return ;
            }
            //failed
            if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
            {
                [self showAlertTips:[_responseObject objectForKey:@"message"]];
                return;
            }
            
            
            //Register in Success
            NSLog(@"%@",_responseObject);
            [[AppData sharedData] setBLoggedIn:YES];
            
            NSMutableDictionary* resultDic = (NSMutableDictionary*) _responseObject;
            NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
            NSMutableDictionary* userDic = [resultDic objectForKey:@"user"];
            [userInfo setObject:userDic forKey:@"user_info"];
            [userInfo synchronize];
            

            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[userDic objectForKey:@"group_id"] integerValue] == 2) {
                TaxiVC* vcTaxi = [self.storyboard instantiateViewControllerWithIdentifier:@"TaxiVC"];
                [self.navigationController pushViewController:vcTaxi animated:YES];
            }
            else {
                MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
                [self.navigationController pushViewController:vcMainWork animated:YES];
            }
        };
        void (^failure)(NSError *_error) = ^(NSError *_error)
        {
            //error
            [self showAlertTips:@"Internet Connection Error!"];
        };
        
        [[SocialManager sharedManager] Register:[txtEmail text]
                                       username:[txtUsername text]
                                        groupId:selGroupId
                              security_question:selQuestionId
                                security_answer:[txtAnswer text]
                                       password:[txtPassword text]
                                        fbtoken:fbtokenId
                                     socialType:socialType
                                      successed:successed
                                        failure:failure];
    }
}

#pragma mark-registerWithSocial
- (void) registerWithSocial:(NSString*) social_type {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@", _responseObject);
        [[AppData sharedData] setBLoggedIn:YES];

        NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary* userDic = [_responseObject objectForKey:@"user"];
        [userInfo setObject:userDic forKey:@"user_info"];
        [userInfo synchronize];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
        [self.navigationController pushViewController:vcMainWork animated:YES];
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] SignInWithSocial:strEmail
                                         socialType:social_type
                                            fbtoken:fbtokenId
                                          successed:successed
                                            failure:failure];
}

#pragma mark-registerWithFB
- (IBAction)registWithFB:(id)sender {
    [txtPassword setEnabled:NO];
    bSocial = YES;
    socialType = @"Facebook";
    if ([FBSDKAccessToken currentAccessToken]) {
        [self fetchUserData];
    } else {
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends", @"user_photos", @"user_birthday", @"user_location"] handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            if (error != nil) {
                [[[UIAlertView alloc] initWithTitle:@"Facebook Login Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            } else if (result.isCancelled) {
                return;
            } else {
                if ([result.grantedPermissions containsObject:@"email"]) {
                    [self fetchUserData];
                }
            }
        }];
    }
}

- (void) fetchUserData {
    if ([FBSDKAccessToken currentAccessToken]) {
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"name, email,friends,gender"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (error != nil) {
                 [[[UIAlertView alloc] initWithTitle:@"Facebook Login Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
             }
             
             NSLog(@"%@", result);
             [self registerWithFacebookInfo:result];
         }];
    }
}
- (void)registerWithFacebookInfo:(NSDictionary*)user {
    NSString* fbProfilePhoto = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large", user[@"id"]];
    
    strPassword = @"";
    strEmail = user[@"email"];
    fbtokenId = user[@"id"];
    
    [fbUserData setObject:user[@"name"] forKey:@"userName"];
    [fbUserData setObject:user[@"email"] forKey:@"email"];
    [fbUserData setObject:user[@"id"] forKey:@"fbId"];
    [fbUserData setObject:fbProfilePhoto forKey:@"photoUrl"];
    [fbUserData setObject:user[@"gender"] forKey:@"sex"];
    
    [txtUsername setText:user[@"name"]];
    [txtEmail setText:strEmail];
    
    //[self registerWithSocial:@"Facebook"];
}

#pragma mark-registerWithTwitter
- (void) twitterLogin {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@", _responseObject);
        [[AppData sharedData] setBLoggedIn:YES];
        
        NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary* userDic = [_responseObject objectForKey:@"user"];
        [userInfo setObject:userDic forKey:@"user_info"];
        [userInfo synchronize];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
        [self.navigationController pushViewController:vcMainWork animated:YES];
        
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] SignInWithTwitter:strEmail
                                             fbtoken:fbtokenId
                                           successed:successed
                                             failure:failure];
    
}

- (IBAction)registWithTwitter:(id)sender {
    [txtPassword setEnabled:NO];
    bSocial = YES;
    socialType = @"Twitter";
    UIViewController *loginController = [[FHSTwitterEngine sharedEngine]loginControllerWithCompletionHandler:^(BOOL success) {
        if (success)
        {
            NSLog(@"Twitter login success");
            
            NSString* strTwitterId = [FHSTwitterEngine sharedEngine].authenticatedID;
            NSString* userName = [FHSTwitterEngine sharedEngine].authenticatedUsername;
            
            strPassword = @"";
            strEmail = userName;
            fbtokenId = strTwitterId;
            
            [txtUsername setText:userName];
            
            
            //[self twitterLogin];
            
            
            NSLog(@"TwitterID: %@", strTwitterId);
        }
        else
        {
            NSLog(@"Twitter login failure");
        }
    }];
    [self presentViewController:loginController animated:YES completion:nil];
}

#pragma mark-registerWithGoogle
- (IBAction)registWithGoogle:(id)sender {
    [txtPassword setEnabled:NO];
    bSocial = YES;
    socialType = @"Google";
    [GPPSignIn sharedInstance].clientID = GooglePluseClientID;
    [GPPSignIn sharedInstance].scopes= [NSArray arrayWithObjects:kGTLAuthScopePlusLogin, nil];
    [GPPSignIn sharedInstance].shouldFetchGoogleUserID=YES;
    [GPPSignIn sharedInstance].shouldFetchGoogleUserEmail=YES;
    [GPPSignIn sharedInstance].delegate=self;
    
    [[GPPSignIn sharedInstance] authenticate];
}

- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    NSLog(@"Received error %@ and auth object %@",error, auth);
    if (error) {
        // Do some error handling here.
    } else {
        [self refreshInterfaceBasedOnSignIn];
    }
}

-(void)refreshInterfaceBasedOnSignIn {
    if ([[GPPSignIn sharedInstance] authentication]) {
        // The user is signed in.
        // Perform other actions here, such as showing a sign-out button
        [plusService setAuthorizer:[GPPSignIn sharedInstance].authentication];
        GTLQueryPlus *query = [GTLQueryPlus queryForPeopleGetWithUserId:@"me"];
        
        [plusService executeQuery:query
                completionHandler:^(GTLServiceTicket *ticket,
                                    GTLPlusPerson *person,
                                    NSError *error) {
                    if (error) {
                        GTMLoggerError(@"Error: %@", error);
                    } else {
                        NSLog(@"%@", person);
                        // Retrieve the display name and "about me" text
                        NSMutableArray* emails = [person.JSON objectForKey:@"emails"];
                        NSMutableDictionary* emailDic = [emails objectAtIndex:0];
                        
                        NSString* email = [emailDic objectForKey:@"value"];
                        NSString* strId = [person.JSON objectForKey:@"id"];
                        
                        fbtokenId = strId;
                        strEmail = email;
                        strPassword = @"";
                        NSString* strUserName = [person.JSON objectForKey:@"displayName"];
                        
                        [txtEmail setText:strEmail];
                        [txtUsername setText:strUserName];
                        
                        //[self registerWithSocial:@"Google"];
                        
                    }
                }];
    } else {
        // Perform other actions here
    }
}

#pragma mark-textField delegates
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField.tag == 422) {
        [dropDownGroup openAnimation];
        nDropdownTag = 1;
        return NO;
    }
    else if (textField.tag == 727) {
        [dropDownQuestion openAnimation];
        nDropdownTag = 2;
        return NO;
    }
    return YES;
}

#pragma mark-AlertView
- (void)showAlertTips:(NSString *)_message
{
    UIAlertView *messageView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                          message:_message
                                                         delegate:self
                                                cancelButtonTitle:@"Ok"
                                                otherButtonTitles:nil, nil];
    [messageView show];
}

#pragma mark- DropDownView
-(void)dropDownCellSelected:(NSInteger)returnIndex{
    if (nDropdownTag == 1) {
        NSString* strGroup = [arrGroupName objectAtIndex:returnIndex];
        [txtSelectOne setText:strGroup];
        selGroupId = [arrGroupID objectAtIndex:returnIndex];
        
    }
    else {
        NSString* strDescription = [arrQuestion objectAtIndex:returnIndex];
        [txtSecretQuestion setText:strDescription];
        selQuestionId = [arrQuestionID objectAtIndex:returnIndex];
    }
}


@end
