//
//  LoginVC.h
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController<UITextFieldDelegate, UIAlertViewDelegate, GPPSignInDelegate> {
    NSString* strEmail;
    NSString* strPassword;
    NSString* fbtokenId;
    
    NSMutableDictionary *fbUserData;
    GTLServicePlus* plusService;
}

@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnFB;
@property (strong, nonatomic) IBOutlet UIButton *btnGoogle;
@property (strong, nonatomic) IBOutlet UIButton *btnTwitter;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet UIButton *btnLogin;
@property (strong, nonatomic) IBOutlet UIImageView *coverImgView;
@property (strong, nonatomic) IBOutlet UIView *alertView;
@property (strong, nonatomic) IBOutlet UIButton *btnOK;
@property (strong, nonatomic) IBOutlet UILabel *lblSuccess;
@property (strong, nonatomic) IBOutlet UIWebView *webView;

- (IBAction)loginWithEmail:(id)sender;
- (IBAction)gotoForgot:(id)sender;
- (IBAction)loginWithFB:(id)sender;
- (IBAction)loginWithGoogle:(id)sender;
- (IBAction)loginWithTwitter:(id)sender;
- (IBAction)gotoBack:(id)sender;
- (IBAction)gotoNextPage:(id)sender;


@end
