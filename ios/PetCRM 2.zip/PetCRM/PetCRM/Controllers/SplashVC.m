//
//  SplashVC.m
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "SplashVC.h"
#import "MainVC.h"
#import "MainWorkVC.h"
#import "TaxiVC.h"

@implementation SplashVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self performSelector:@selector(showNextPage) withObject:nil afterDelay:1.f];
}


#pragma mark - Utility
- (void) showNextPage
{
    if ([AppData sharedData].bLoggedIn == YES)
    {
        [self goToMainScreen];
    }
    else
    {
        MainVC* vcMain = [self.storyboard instantiateViewControllerWithIdentifier:@"MainVC"];
        [self.navigationController pushViewController:vcMain animated:NO];
    }
}

- (void) goToMainScreen
{
    int nGroupId = (int)[[[[NSUserDefaults standardUserDefaults] objectForKey:@"user_info"] objectForKey:@"group_id"] integerValue];
    if (nGroupId == 2) {
        TaxiVC* vcTaxi = [self.storyboard instantiateViewControllerWithIdentifier:@"TaxiVC"];
        [self.navigationController pushViewController:vcTaxi animated:YES];
    }
    else {
        MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
        [self.navigationController pushViewController:vcMainWork animated:YES];
    }
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

@end
