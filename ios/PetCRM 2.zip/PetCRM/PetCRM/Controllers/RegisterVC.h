//
//  RegisterVC.h
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import "TPKeyboardAvoidingScrollView.h"

@interface RegisterVC : UIViewController<UITextFieldDelegate, GPPSignInDelegate, UIAlertViewDelegate, DropDownViewDelegate> {
    NSString* strEmail;
    NSString* strPassword;
    NSString* fbtokenId;
 
    NSMutableDictionary *fbUserData;
    GTLServicePlus* plusService;
    
    NSMutableDictionary* groupDic;
    NSMutableArray* arrGroupName;
    NSMutableArray* arrQuestion;
    NSMutableArray* arrGroupID;
    NSMutableArray* arrQuestionID;
    
    DropDownView *dropDownGroup;
    DropDownView *dropDownQuestion;
    int nDropdownTag;
    
    BOOL bSocial;
    NSString* socialType;
    
    NSString* selGroupId;
    NSString* selQuestionId;
}

@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *registerView;
@property (strong, nonatomic) IBOutlet UITextField *txtUsername;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtSelectOne;
@property (strong, nonatomic) IBOutlet UITextField *txtSecretQuestion;
@property (strong, nonatomic) IBOutlet UITextField *txtAnswer;
@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;

- (IBAction)gotoSubmit:(id)sender;
- (IBAction)registWithFB:(id)sender;
- (IBAction)registWithGoogle:(id)sender;
- (IBAction)registWithTwitter:(id)sender;
- (IBAction)gotoBack:(id)sender;

@end
