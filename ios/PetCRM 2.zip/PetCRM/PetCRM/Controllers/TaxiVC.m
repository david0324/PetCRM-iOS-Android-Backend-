//
//  TaxiVC.m
//  PetCRM
//
//  Created by mac on 01/12/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "TaxiVC.h"

@implementation TaxiVC

- (void) viewDidLoad {
    [super viewDidLoad];
    
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}
@end
