//
//  ForgotPassVC.h
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import "TPKeyboardAvoidingScrollView.h"

@interface ForgotPassVC : UIViewController<UITextFieldDelegate, DropDownViewDelegate> {
    NSString* strQuestion;
    
    DropDownView* dropdownQuestion;
    NSMutableArray* arrQuestion;
    NSMutableArray* arrQuestionID;
    
    NSString* selQuestionId;
}

@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *forgotEditView;
@property (strong, nonatomic) IBOutlet UITextField *txtSecret;
@property (strong, nonatomic) IBOutlet UITextField *txtAnswer;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UIImageView *coverImgView;
@property (strong, nonatomic) IBOutlet UIView *alertView;
@property (strong, nonatomic) IBOutlet UIButton *btnOk;
- (IBAction)gotoBack:(id)sender;
- (IBAction)gotoSubmit:(id)sender;
- (IBAction)gotoNextPage:(id)sender;

@end
