//
//  LoginVC.m
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "LoginVC.h"
#import "ForgotPassVC.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <GoogleOpenSource/GoogleOpenSource.h>
#import "SocialManager.h"
#import "MainWorkVC.h"
#import "TaxiVC.h"

@implementation LoginVC

@synthesize txtEmail, txtPassword, btnBack;
@synthesize btnOK, alertView, coverImgView;
@synthesize lblSuccess;

- (void) viewDidLoad {
    [super viewDidLoad];
    
    [coverImgView setHidden:YES];
    [alertView setHidden:YES];
    [self setTextFieldProperty];
    
    plusService = [[GTLServicePlus alloc] init];
    plusService.retryEnabled = YES;
}

- (void) setTextFieldProperty {
    [txtEmail setDelegate:self];
    [txtEmail setTintColor:[UIColor blackColor]];
    txtEmail.keyboardType = UIKeyboardTypeEmailAddress;
    
    [txtPassword setDelegate:self];
    [txtPassword setTintColor:[UIColor blackColor]];
    txtPassword.keyboardType = UIKeyboardTypeDefault;
    [txtPassword setSecureTextEntry:YES];
}

-(BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

- (BOOL) canLogin
{
    BOOL bResult = YES;
    
    if (txtEmail.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtPassword.text.length < 3)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the password." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    
    if (![self validateEmail:txtEmail.text]){
        
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter valid Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        return NO;
    }
    
    return bResult;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

#pragma mark-login
- (void) login {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@",_responseObject);
        
        NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary* userDic = [_responseObject objectForKey:@"user"];
        [userInfo setObject:userDic forKey:@"user_info"];
        [userInfo synchronize];
        
        [coverImgView setHidden:NO];
        [alertView setHidden:NO];
        [txtEmail setEnabled:NO];
        [txtPassword setEnabled:NO];
        [btnBack setEnabled:NO];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];

    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
        
    [[SocialManager sharedManager]  SignIn:strEmail
                                  password:strPassword
                                 successed:successed
                                   failure:failure];
}

#pragma mark-loginWithEmail
- (IBAction)loginWithEmail:(id)sender {
    if ([self canLogin]) {
        strEmail = txtEmail.text;
        strPassword = txtPassword.text;
        [self login];
    }
}

- (IBAction)gotoForgot:(id)sender {
    ForgotPassVC* vcForgotPass = [self.storyboard instantiateViewControllerWithIdentifier:@"ForgotPassVC"];
    [self.navigationController pushViewController:vcForgotPass animated:YES];
}

#pragma mark-loginWithSocial
- (void) loginWithSocial:(NSString*) social_type {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@", _responseObject);
        [[AppData sharedData] setBLoggedIn:YES];
        
        NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary* userDic = [_responseObject objectForKey:@"user"];
        [userInfo setObject:userDic forKey:@"user_info"];
        [userInfo synchronize];
        
        [coverImgView setHidden:NO];
        [alertView setHidden:NO];
        [txtEmail setEnabled:NO];
        [txtPassword setEnabled:NO];
        [btnBack setEnabled:NO];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] SignInWithSocial:strEmail
                                         socialType:social_type
                                            fbtoken:fbtokenId
                                          successed:successed
                                            failure:failure];
}

#pragma mark-loginWithFB
- (IBAction)loginWithFB:(id)sender {
    if ([FBSDKAccessToken currentAccessToken]) {
        [self fetchUserData];
    } else {
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends", @"user_photos", @"user_birthday", @"user_location"] handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            if (error != nil) {
                [[[UIAlertView alloc] initWithTitle:@"Facebook Login Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            } else if (result.isCancelled) {
                return;
            } else {
                if ([result.grantedPermissions containsObject:@"email"]) {
                    [self fetchUserData];
                }
            }
        }];
    }
}

- (void) fetchUserData {
    if ([FBSDKAccessToken currentAccessToken]) {
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"name, email,friends,gender"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (error != nil) {
                 [[[UIAlertView alloc] initWithTitle:@"Facebook Login Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
             }
             
             NSLog(@"%@", result);
             [self loginWithFacebookInfo:result];
         }];
    }
}
- (void)loginWithFacebookInfo:(NSDictionary*)user {
    NSString* fbProfilePhoto = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large", user[@"id"]];
    
    strPassword = @"";
    strEmail = user[@"email"];
    fbtokenId = user[@"id"];
    
    
    [fbUserData setObject:user[@"name"] forKey:@"userName"];
    [fbUserData setObject:user[@"email"] forKey:@"email"];
    [fbUserData setObject:user[@"id"] forKey:@"fbId"];
    [fbUserData setObject:fbProfilePhoto forKey:@"photoUrl"];
    [fbUserData setObject:user[@"gender"] forKey:@"sex"];
    
    [self loginWithSocial:@"Facebook"];
}

#pragma mark-loginWithTwitter
- (void) twitterLogin {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        //Log in Success
        NSLog(@"%@", _responseObject);
       [[AppData sharedData] setBLoggedIn:YES];
        
        NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary* userDic = [_responseObject objectForKey:@"user"];
        [userInfo setObject:userDic forKey:@"user_info"];
        [userInfo synchronize];
        
        [coverImgView setHidden:NO];
        [alertView setHidden:NO];
        [txtEmail setEnabled:NO];
        [txtPassword setEnabled:NO];
        [btnBack setEnabled:NO];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] SignInWithTwitter:strEmail
                                             fbtoken:fbtokenId
                                           successed:successed
                                             failure:failure];

}

- (IBAction)loginWithTwitter:(id)sender {
    UIViewController *loginController = [[FHSTwitterEngine sharedEngine]loginControllerWithCompletionHandler:^(BOOL success) {
        if (success)
        {
            NSLog(@"Twitter login success");
            
            NSString* strTwitterId = [FHSTwitterEngine sharedEngine].authenticatedID;
            NSString* userName = [FHSTwitterEngine sharedEngine].authenticatedUsername;
          
            strPassword = @"";
            strEmail = userName;
            fbtokenId = strTwitterId;
            
            [self twitterLogin];

 
            NSLog(@"TwitterID: %@", strTwitterId);
        }
        else
        {
            NSLog(@"Twitter login failure");
        }
    }];
    [self presentViewController:loginController animated:YES completion:nil];
}

#pragma mark-loginWithGoogle+
- (IBAction)loginWithGoogle:(id)sender {
    [GPPSignIn sharedInstance].clientID = GooglePluseClientID;
    [GPPSignIn sharedInstance].scopes= [NSArray arrayWithObjects:kGTLAuthScopePlusLogin, nil];
    [GPPSignIn sharedInstance].shouldFetchGoogleUserID=YES;
    [GPPSignIn sharedInstance].shouldFetchGoogleUserEmail=YES;
    [GPPSignIn sharedInstance].delegate=self;
    
    [[GPPSignIn sharedInstance] authenticate];
}

- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    NSLog(@"Received error %@ and auth object %@",error, auth);
    if (error) {
        // Do some error handling here.
    } else {
        [self refreshInterfaceBasedOnSignIn];
    }
}

-(void)refreshInterfaceBasedOnSignIn {
    if ([[GPPSignIn sharedInstance] authentication]) {
        // The user is signed in.
        // Perform other actions here, such as showing a sign-out button
        [plusService setAuthorizer:[GPPSignIn sharedInstance].authentication];
        GTLQueryPlus *query = [GTLQueryPlus queryForPeopleGetWithUserId:@"me"];
        
        [plusService executeQuery:query
                completionHandler:^(GTLServiceTicket *ticket,
                                    GTLPlusPerson *person,
                                    NSError *error) {
                    if (error) {
                        GTMLoggerError(@"Error: %@", error);
                    } else {
                        NSLog(@"%@", person);
                        // Retrieve the display name and "about me" text
                        NSMutableArray* emails = [person.JSON objectForKey:@"emails"];
                        NSMutableDictionary* emailDic = [emails objectAtIndex:0];
                        
                        NSString* email = [emailDic objectForKey:@"value"];
                        NSString* strId = [person.JSON objectForKey:@"id"];
                        
                        fbtokenId = strId;
                        strEmail = email;
                        strPassword = @"";
                       
                        [self loginWithSocial:@"Google"];
                        
                    }
                }];
    } else {
        // Perform other actions here
    }
}

#pragma --mark goto method
- (IBAction)gotoBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)gotoNextPage:(id)sender {
    int nGroupId = (int)[[[[NSUserDefaults standardUserDefaults] objectForKey:@"user_info"] objectForKey:@"group_id"] integerValue];
    if (nGroupId == 2) {
        TaxiVC* vcTaxi = [self.storyboard instantiateViewControllerWithIdentifier:@"TaxiVC"];
        [self.navigationController pushViewController:vcTaxi animated:YES];
    }
    else {
        MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
        [self.navigationController pushViewController:vcMainWork animated:YES];
    }
}

#pragma mark-textField delegates
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}

#pragma mark-AlertView
- (void)showAlertTips:(NSString *)_message
{
    UIAlertView *messageView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:_message
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    [messageView show];
}
@end
