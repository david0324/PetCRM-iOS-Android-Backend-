//
//  SplashVC.h
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashVC : UIViewController

@end
