//
//  ForgotPassVC.m
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "ForgotPassVC.h"
#import "SocialManager.h"

@implementation ForgotPassVC
@synthesize txtEmail, txtSecret, txtAnswer, forgotEditView;
@synthesize coverImgView, alertView, btnBack;

- (void) viewDidLoad {
    [super viewDidLoad];
    
    arrQuestion = [[NSMutableArray alloc] init];
    arrQuestionID = [[NSMutableArray alloc] init];
    [self getSecurityQuestion];
    [self setTextFieldProperty];
    [coverImgView setHidden:YES];
    [alertView setHidden:YES];
}

- (void) setTextFieldProperty {
    [txtEmail setDelegate:self];
    [txtEmail setTintColor:[UIColor blackColor]];
    txtEmail.keyboardType = UIKeyboardTypeEmailAddress;
    
    [txtSecret setDelegate:self];
    [txtSecret setTintColor:[UIColor blackColor]];
    txtSecret.keyboardType = UIKeyboardTypeDefault;
    [txtSecret setTag:422];
    
    [txtAnswer setDelegate:self];
    [txtAnswer setTintColor:[UIColor blackColor]];
    txtAnswer.keyboardType = UIKeyboardTypeDefault;
}

-(void)initDropdown {
    dropdownQuestion = [[DropDownView alloc] initWithArrayData:arrQuestion cellHeight:30 heightTableView:30 * 4 paddingTop:-8 paddingLeft:-5 paddingRight:-10 refView:txtSecret animation:BLENDIN openAnimationDuration:0 closeAnimationDuration:0];
    
    dropdownQuestion.delegate_ = self;
    
    [forgotEditView addSubview:dropdownQuestion.view];
    
}

- (void)getSecurityQuestion {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    void (^successed)(id _responseObject) = ^(id _responseObject)
    {
        if ([_responseObject isEqual:nil])
        {
            [self showAlertTips:@"Connection Problem"];
            return ;
        }
        //failed
        if ([[_responseObject objectForKey:@"error"] intValue] > 0)
        {
            [self showAlertTips:[_responseObject objectForKey:@"message"]];
            return;
        }
        
        
        //Log in Success
        NSLog(@"%@",_responseObject);
        [[AppData sharedData].arrQuestion removeAllObjects];
        
        NSMutableDictionary* questionDic = (NSMutableDictionary*)_responseObject;
        
        if ([[questionDic objectForKey:@"error"] boolValue] == NO ) {
            NSMutableArray* arrQuestionDic = [questionDic objectForKey:@"securities"];
            for (NSDictionary* dic in arrQuestionDic) {
                NSString* strDescription = [dic objectForKey:@"description"];
                [arrQuestion addObject:strDescription];
                [arrQuestionID addObject:[dic objectForKey:@"id"]];
            }
            
            [AppData sharedData].arrQuestion = arrQuestion;
            [self initDropdown];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    };
    void (^failure)(NSError *_error) = ^(NSError *_error)
    {
        //error
        [self showAlertTips:@"Internet Connection Error!"];
    };
    
    [[SocialManager sharedManager] GetSecurityQuestion:@""
                                             successed:successed
                                               failure:failure];
}

- (IBAction)gotoBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)gotoSubmit:(id)sender {
    if ([self canSubmit]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        void (^successed)(id _responseObject) = ^(id _responseObject)
        {
            if ([_responseObject isEqual:nil])
            {
                [self showAlertTips:@"Connection Problem"];
                return ;
            }
            //failed
            if ([[_responseObject objectForKey:@"error_code"] intValue] > 0)
            {
                [self showAlertTips:[_responseObject objectForKey:@"message"]];
                return;
            }
            
            
            //Register in Success
            NSLog(@"%@",_responseObject);
            
            NSMutableDictionary* resultDic = (NSMutableDictionary*) _responseObject;
            NSUserDefaults* userInfo = [NSUserDefaults standardUserDefaults];
            NSMutableDictionary* userDic = [resultDic objectForKey:@"user"];
            [userInfo setObject:userDic forKey:@"user_info"];
            [userInfo synchronize];
 
            [coverImgView setHidden:NO];
            [alertView setHidden:NO];
            [txtEmail setEnabled:NO];
            [txtSecret setEnabled:NO];
            [txtAnswer setEnabled:NO];
            [btnBack setEnabled:NO];
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
           
        };
        void (^failure)(NSError *_error) = ^(NSError *_error)
        {
            //error
            [self showAlertTips:@"Internet Connection Error!"];
        };
        
        [[SocialManager sharedManager] ForgotPassword:[txtEmail text]
                                       security_question:selQuestionId
                                        security_answer:[txtAnswer text]
                                      successed:successed
                                        failure:failure];
    }
}

- (IBAction)gotoNextPage:(id)sender {   
    [self.navigationController popViewControllerAnimated:YES];
}

-(BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

- (BOOL) canSubmit
{
    BOOL bResult = YES;
    
    if (txtEmail.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtSecret.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the secret question." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    else if (txtAnswer.text.length == 0)
    {
        UIAlertView* alert=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the answer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO;
        
    }
    
    if (![self validateEmail:txtEmail.text]){
        
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter valid Email address." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
        return NO;
    }
    
    return bResult;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

#pragma mark-textField delegates

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField.tag == 422) {
        [dropdownQuestion openAnimation];
        return NO;
    }
    return YES;
}

#pragma mark-AlertView
- (void)showAlertTips:(NSString *)_message
{
    UIAlertView *messageView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                          message:_message
                                                         delegate:self
                                                cancelButtonTitle:@"Ok"
                                                otherButtonTitles:nil, nil];
    [messageView show];
}

#pragma mark- DropDownView
-(void)dropDownCellSelected:(NSInteger)returnIndex{
    strQuestion = [arrQuestion objectAtIndex:returnIndex];
    [txtSecret setText:strQuestion];
    selQuestionId = [arrQuestionID objectAtIndex:returnIndex];
}


@end
