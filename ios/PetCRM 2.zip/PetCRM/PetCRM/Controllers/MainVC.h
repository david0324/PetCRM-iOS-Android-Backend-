//
//  LoginVC.h
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainVC : UIViewController

- (IBAction)gotoPreview:(id)sender;
- (IBAction)gotoGetStarted:(id)sender;
- (IBAction)gotoLogin:(id)sender;
@end
