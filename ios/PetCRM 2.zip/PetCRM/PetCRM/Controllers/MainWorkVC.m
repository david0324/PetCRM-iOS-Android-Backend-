//
//  MainWorkVC.m
//  PetCRM
//
//  Created by mac on 30/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "MainWorkVC.h"

@implementation MainWorkVC


- (BOOL)prefersStatusBarHidden {
    return YES;
}

@end
