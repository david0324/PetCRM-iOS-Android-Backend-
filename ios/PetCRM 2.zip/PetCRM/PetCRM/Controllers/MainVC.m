//
//  LoginVC.m
//  PetCRM
//
//  Created by mac on 28/11/15.
//  Copyright © 2015 Robert. All rights reserved.
//

#import "LoginVC.h"
#import "MainVC.h"
#import "RegisterVC.h"
#import "MainWorkVC.h"

@implementation MainVC

- (void) viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)gotoPreview:(id)sender {
    MainWorkVC* vcMainWork = [self.storyboard instantiateViewControllerWithIdentifier:@"MainWorkVC"];
    [self.navigationController pushViewController:vcMainWork animated:YES];
}

- (IBAction)gotoGetStarted:(id)sender {
    RegisterVC* vcRegister = [self.storyboard instantiateViewControllerWithIdentifier:@"RegisterVC"];
    [self.navigationController pushViewController:vcRegister animated:YES];
}

- (IBAction)gotoLogin:(id)sender {
    
    LoginVC* vcLogin = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
    [self.navigationController pushViewController:vcLogin animated:YES];
    
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

@end
